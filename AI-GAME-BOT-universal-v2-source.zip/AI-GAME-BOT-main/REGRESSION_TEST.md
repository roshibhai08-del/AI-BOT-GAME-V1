# AI Game Bot regression checklist

Target screen: MathGro — `7² = ?` with options `46, 49, 48, 44`.

Expected pipeline:

1. Auto Detect starts in discovery mode.
2. Foreground package/app label is checked before gameplay.
3. Identity is shown with its source and confidence.
4. Screen is analyzed for question/options.
5. Math engine normalizes `²` / `^2` and calculates `49`.
6. The `49` answer target is selected from detected bounds; no blind action is allowed when confidence is low.
7. Action is TAP only when the action confidence threshold is met.
8. The next frame is captured and the result is verified before replanning.

Important: a real device regression requires an actual MediaProjection capture and Accessibility permission. The simulator can be used for UI/pipeline checks, but it is not proof of third-party-game control.
