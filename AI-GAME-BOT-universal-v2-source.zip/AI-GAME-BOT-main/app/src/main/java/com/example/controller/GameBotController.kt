package com.example.controller

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import com.example.ai.GameBotAiEngine
import com.example.engine.AccessibilityController
import com.example.engine.ActionPlanner
import com.example.engine.CalibrationManager
import com.example.engine.CoordinateMapper
import com.example.engine.FailureRecovery
import com.example.engine.GameClassifier
import com.example.engine.GameStateManager
import com.example.engine.GestureResult
import com.example.engine.LevelManager
import com.example.engine.OCRManager
import com.example.engine.ObjectDetector
import com.example.engine.StrategyEngine
import com.example.engine.VictoryDetector
import com.example.model.ActionType
import com.example.model.BotAction
import com.example.model.BotConfig
import com.example.model.BotState
import com.example.model.GameStateStatus
import com.example.model.PlannedAction
import com.example.service.GameBotAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

interface SimulatorGameDelegate {
    fun captureFrame(): Bitmap
    fun onSimulatedTap(x: Float, y: Float)
    fun onSimulatedSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long)
    fun getGameTitle(): String
    fun getGameGenre(): String
    fun getPackageName(): String = "com.aistudio.game"
}

class GameBotController(private val context: Context) {

    companion object {
        private const val TAG = "GameBotController"
        var instance: GameBotController? = null
            private set

        fun initialize(context: Context): GameBotController {
            if (instance == null) {
                instance = GameBotController(context.applicationContext)
            }
            return instance!!
        }
    }

    private val controllerScope = CoroutineScope(Dispatchers.Default + Job())
    private var botJob: Job? = null

    private val _botConfig = MutableStateFlow(BotConfig())
    val botConfig = _botConfig.asStateFlow()

    private val _botState = MutableStateFlow(BotState())
    val botState = _botState.asStateFlow()

    // Modular Universal Game Architecture Components
    val coordinateMapper = CoordinateMapper(context)
    val ocrManager = OCRManager()
    val objectDetector = ObjectDetector()
    val gameClassifier = GameClassifier()
    val gameStateManager = GameStateManager()
    val levelManager = LevelManager()
    val victoryDetector = VictoryDetector()
    val failureRecovery = FailureRecovery()
    val strategyEngine = StrategyEngine(coordinateMapper, ocrManager, victoryDetector, failureRecovery)
    val foregroundAppDetector = ForegroundAppDetector(context)
    val gameIdentityDetector = GameIdentityDetector(foregroundAppDetector, ocrManager)
    val mathEngine = MathEngine(coordinateMapper)
    val actionPlanner = ActionPlanner(
        coordinateMapper,
        gameIdentityDetector,
        gameClassifier,
        objectDetector,
        ocrManager,
        mathEngine,
        levelManager,
        strategyEngine
    )
    val accessibilityController = AccessibilityController()
    val calibrationManager = CalibrationManager(context)

    private val aiEngine = GameBotAiEngine { _botConfig.value }

    var activeSimulator: SimulatorGameDelegate? = null

    init {
        // Set initial calibration from storage
        _botState.update { it.copy(calibrationProfile = calibrationManager.currentProfile) }

        // Setup Game Switch listener
        gameStateManager.onGameSwitchDetected = {
            Log.d(TAG, "Screen changed significantly! Resetting previous game state and strategy.")
            levelManager.reset()
            failureRecovery.reset()
            _botState.update {
                it.copy(
                    currentGameName = "New Game Detected - Refreshing...",
                    gameStateStatus = GameStateStatus.DISCOVERY,
                    currentObjective = "Discovering new game screen layout",
                    statusMessage = "🔄 Game switch detected! Resetting strategy."
                )
            }
        }
    }

    fun updateConfig(update: (BotConfig) -> BotConfig) {
        _botConfig.update(update)
    }

    fun updateAccessibilityStatus(isEnabled: Boolean) {
        _botState.update { it.copy(isAccessibilityEnabled = isEnabled) }
    }

    fun updateOverlayStatus(isGranted: Boolean) {
        _botState.update { it.copy(isOverlayPermissionGranted = isGranted) }
    }

    fun updateScreenCaptureStatus(isActive: Boolean) {
        _botState.update { it.copy(isScreenCaptureActive = isActive) }
    }

    fun updateCalibration(offsetX: Float, offsetY: Float, scaleX: Float, scaleY: Float) {
        calibrationManager.updateCalibration(offsetX, offsetY, scaleX, scaleY)
        _botState.update { it.copy(calibrationProfile = calibrationManager.currentProfile) }
    }

    fun resetCalibration() {
        calibrationManager.resetCalibration(coordinateMapper.physicalWidth, coordinateMapper.physicalHeight)
        _botState.update { it.copy(calibrationProfile = calibrationManager.currentProfile) }
    }

    fun startBot() {
        if (_botState.value.isBotRunning) return

        _botState.update {
            it.copy(
                isBotRunning = true,
                isPaused = false,
                isStepMode = false,
                isDetectingGame = true,
                currentStep = 0,
                sessionStartTime = System.currentTimeMillis(),
                statusMessage = "Detecting Game..."
            )
        }

        botJob = controllerScope.launch {
            // STEP 1: FOREGROUND APP & GAME IDENTITY DETECTION FIRST
            val warmupFrame = getScreenBitmap()
            val simulatedPkg = activeSimulator?.getPackageName()
            val textStrings = if (warmupFrame != null) {
                ocrManager.detectTextRegionsHeuristic(warmupFrame).map { it.text }
            } else emptyList()

            val detectedIdentity = gameIdentityDetector.detectIdentity(warmupFrame, textStrings, simulatedPkg)
            val detectedClassification = gameClassifier.classify(warmupFrame, textStrings, detectedIdentity.gameName)

            _botState.update {
                it.copy(
                    isDetectingGame = false,
                    currentGameName = detectedIdentity.gameName,
                    gameCategory = detectedClassification.category,
                    identitySource = detectedIdentity.source,
                    confidenceScore = detectedIdentity.confidence * 100f,
                    statusMessage = "Game: ${detectedIdentity.gameName} [${detectedIdentity.source.label}] (${(detectedIdentity.confidence * 100).toInt()}% Conf)"
                )
            }

            // Display identity first before gameplay begins
            delay(500)

            val max = _botConfig.value.maxSteps
            while (isActive && _botState.value.isBotRunning && _botState.value.currentStep < max) {
                if (_botState.value.isPaused) {
                    delay(300)
                    continue
                }

                executeSingleStep()

                val delayMillis = (_botConfig.value.delaySeconds * 1000).toLong().coerceAtLeast(200)
                delay(delayMillis)
            }

            if (_botState.value.currentStep >= max) {
                _botState.update {
                    it.copy(
                        isBotRunning = false,
                        statusMessage = "MAX_STEPS ($max) reached. Bot stopped."
                    )
                }
            }
        }
    }

    fun pauseBot() {
        _botState.update {
            it.copy(
                isPaused = !it.isPaused,
                statusMessage = if (!it.isPaused) "Bot paused" else "Bot running..."
            )
        }
    }

    fun stopBot() {
        botJob?.cancel()
        botJob = null
        _botState.update {
            it.copy(
                isBotRunning = false,
                isPaused = false,
                isStepMode = false,
                isDetectingGame = false,
                statusMessage = "Bot stopped"
            )
        }
    }

    /**
     * "1 STEP" Mode:
     * Captures screen, detects game & objective, plans 1 action, and updates debug state.
     * DOES NOT EXECUTE THE ACTION AUTOMATICALLY.
     */
    fun planSingleStepOnly() {
        controllerScope.launch {
            val nextStep = _botState.value.currentStep + 1
            _botState.update {
                it.copy(
                    isStepMode = true,
                    statusMessage = "1 STEP Mode: Capturing frame & planning action..."
                )
            }

            val bitmap = getScreenBitmap()
            if (bitmap == null) {
                _botState.update {
                    it.copy(statusMessage = "SCREEN CAPTURE LOST - Please grant capture permission")
                }
                return@launch
            }

            // Check game switch
            gameStateManager.processFrame(bitmap)

            // Full dynamic analysis and plan
            val plan = actionPlanner.analyzeAndPlan(
                bitmap = bitmap,
                explicitTarget = _botConfig.value.targetGame,
                calibration = _botState.value.calibrationProfile,
                minConfidenceThreshold = _botConfig.value.minConfidenceThreshold,
                stepNumber = nextStep,
                simulatedPackage = activeSimulator?.getPackageName()
            )

            _botState.update {
                it.copy(
                    currentGameName = plan.gameTitle,
                    gameCategory = plan.category,
                    currentGenre = plan.category.displayName,
                    identitySource = plan.identitySource,
                    gameStateStatus = plan.stateStatus,
                    currentObjective = plan.objective,
                    currentLevel = plan.level,
                    currentQuestion = plan.questionText,
                    currentOptions = plan.optionsText,
                    calculatedAnswer = plan.calculatedAnswer,
                    targetAnswer = plan.selectedAnswer,
                    confidenceScore = plan.plannedAction.confidence,
                    pendingStepAction = plan.plannedAction,
                    debugOverlayState = plan.debugOverlayState,
                    statusMessage = "1 STEP Planned: [${plan.plannedAction.actionType.label}] ${plan.plannedAction.thought} (${plan.plannedAction.confidence.toInt()}% Conf)"
                )
            }
        }
    }

    /**
     * "EXECUTE STEP" Mode:
     * Executes the currently planned action from "1 STEP" mode.
     */
    fun executePlannedStep() {
        val planned = _botState.value.pendingStepAction
        if (planned == null) {
            _botState.update { it.copy(statusMessage = "No planned step. Press '1 STEP' first.") }
            return
        }

        controllerScope.launch {
            // Check confidence safety
            if (planned.confidence < _botConfig.value.minConfidenceThreshold) {
                _botState.update {
                    it.copy(
                        statusMessage = "LOW CONFIDENCE (${planned.confidence.toInt()}%) — WAITING / REANALYZING. Action cancelled."
                    )
                }
                return@launch
            }

            // Check Accessibility readiness
            if (!accessibilityController.isReady && activeSimulator == null) {
                _botState.update {
                    it.copy(statusMessage = "ACCESSIBILITY SERVICE NOT READY - Please enable in settings")
                }
                return@launch
            }

            vibrateFeedback()

            // Dispatch gesture
            if (activeSimulator != null) {
                when (planned.actionType) {
                    ActionType.TAP, ActionType.RETRY -> activeSimulator?.onSimulatedTap(planned.startX.toFloat(), planned.startY.toFloat())
                    ActionType.SWIPE, ActionType.SWIPE_UP, ActionType.SWIPE_DOWN,
                    ActionType.SWIPE_LEFT, ActionType.SWIPE_RIGHT -> activeSimulator?.onSimulatedSwipe(
                        planned.startX.toFloat(), planned.startY.toFloat(),
                        planned.endX.toFloat(), planned.endY.toFloat(), planned.durationMs
                    )
                    else -> {}
                }
            } else {
                accessibilityController.executeAction(planned) { result ->
                    when (result) {
                        is GestureResult.Success -> Log.d(TAG, "Step action executed successfully")
                        is GestureResult.Failure -> Log.e(TAG, "Step action failed: ${result.reason}")
                        is GestureResult.ServiceNotReady -> Log.w(TAG, "ACCESSIBILITY SERVICE NOT READY")
                    }
                }
            }

            // Closed loop verification
            delay(300)
            val newBmp = getScreenBitmap()
            val verified = if (newBmp != null) gameStateManager.verifyActionEffect(newBmp) else true

            _botState.update {
                val nextStep = it.currentStep + 1
                val convertedBotAction = BotAction(
                    game = it.currentGameName,
                    genre = it.currentGenre,
                    thought = planned.thought,
                    action = planned.actionType,
                    x = planned.startX,
                    y = planned.startY,
                    x2 = planned.endX,
                    y2 = planned.endY,
                    durationMs = planned.durationMs.toInt(),
                    stepNumber = nextStep,
                    confidence = planned.confidence,
                    expectedResult = planned.expectedResult,
                    actualResult = if (verified) "Screen changed as expected" else "No noticeable screen change"
                )

                it.copy(
                    currentStep = nextStep,
                    lastAction = convertedBotAction,
                    recentActions = (it.recentActions + convertedBotAction).takeLast(30),
                    pendingStepAction = null,
                    totalGesturesDispatched = it.totalGesturesDispatched + 1,
                    statusMessage = "Step executed [${planned.actionType.label}]. Result: ${if (verified) "Verified ✅" else "Screen Unchanged ⚠️"}"
                )
            }
        }
    }

    fun executeSingleStep() {
        controllerScope.launch {
            val nextStep = _botState.value.currentStep + 1

            // 1. Obtain bitmap
            val bitmap = getScreenBitmap()
            if (bitmap == null) {
                _botState.update {
                    it.copy(statusMessage = "SCREEN CAPTURE LOST - Waiting for frame...")
                }
                return@launch
            }

            // 2. Check for Game Switch (app switch / screen shift)
            val isSwitched = gameStateManager.processFrame(bitmap)
            if (isSwitched) {
                return@launch
            }

            // 3. Run ActionPlanner (Detects Game Identity, Math Question, or Game Classification)
            val plan = actionPlanner.analyzeAndPlan(
                bitmap = bitmap,
                explicitTarget = _botConfig.value.targetGame,
                calibration = _botState.value.calibrationProfile,
                minConfidenceThreshold = _botConfig.value.minConfidenceThreshold,
                stepNumber = nextStep,
                simulatedPackage = activeSimulator?.getPackageName()
            )

            val planned = if (plan.category == GameCategory.MATH_QUIZ || plan.plannedAction.confidence >= 85f) {
                plan.plannedAction
            } else {
                // Ask AI Vision Engine if complex arcade game
                val history = _botState.value.recentActions.takeLast(5).map { it.toActionString() }
                val (aiAction, _) = aiEngine.analyzeScreenshot(bitmap, history, nextStep)

                val physicalPoint = coordinateMapper.screenshotToPhysical(
                    aiAction.x.toFloat(),
                    aiAction.y.toFloat(),
                    _botConfig.value.imgWidth,
                    (bitmap.height / (bitmap.width.toFloat() / _botConfig.value.imgWidth.toFloat())).toInt(),
                    _botState.value.calibrationProfile
                )

                val physicalPoint2 = coordinateMapper.screenshotToPhysical(
                    aiAction.x2.toFloat(),
                    aiAction.y2.toFloat(),
                    _botConfig.value.imgWidth,
                    (bitmap.height / (bitmap.width.toFloat() / _botConfig.value.imgWidth.toFloat())).toInt(),
                    _botState.value.calibrationProfile
                )

                PlannedAction(
                    actionType = aiAction.action,
                    startX = physicalPoint.x.toInt(),
                    startY = physicalPoint.y.toInt(),
                    endX = physicalPoint2.x.toInt(),
                    endY = physicalPoint2.y.toInt(),
                    durationMs = aiAction.durationMs.toLong(),
                    confidence = aiAction.confidence,
                    thought = aiAction.thought,
                    objective = _botState.value.currentObjective,
                    expectedResult = aiAction.expectedResult,
                    stepNumber = nextStep
                )
            }

            // 4. Confidence Threshold Check (Never randomly tap!)
            if (planned.confidence < _botConfig.value.minConfidenceThreshold) {
                _botState.update {
                    it.copy(
                        statusMessage = "LOW CONFIDENCE (${planned.confidence.toInt()}%) — WAITING / REANALYZING",
                        confidenceScore = planned.confidence,
                        gameStateStatus = GameStateStatus.WAITING_CONFIDENCE
                    )
                }
                return@launch
            }

            // 5. Update state
            _botState.update {
                val convertedBotAction = BotAction(
                    game = plan.gameTitle,
                    genre = plan.category.displayName,
                    thought = planned.thought,
                    action = planned.actionType,
                    x = planned.startX,
                    y = planned.startY,
                    x2 = planned.endX,
                    y2 = planned.endY,
                    durationMs = planned.durationMs.toInt(),
                    stepNumber = nextStep,
                    confidence = planned.confidence,
                    expectedResult = planned.expectedResult
                )
                val updatedRecent = (it.recentActions + convertedBotAction).takeLast(30)
                it.copy(
                    currentStep = nextStep,
                    lastAction = convertedBotAction,
                    recentActions = updatedRecent,
                    currentGameName = plan.gameTitle,
                    currentGenre = plan.category.displayName,
                    gameCategory = plan.category,
                    identitySource = plan.identitySource,
                    currentQuestion = plan.questionText,
                    currentOptions = plan.optionsText,
                    calculatedAnswer = plan.calculatedAnswer,
                    targetAnswer = plan.selectedAnswer,
                    confidenceScore = planned.confidence,
                    debugOverlayState = plan.debugOverlayState,
                    statusMessage = "[${planned.actionType.label}] ${planned.thought}",
                    totalGesturesDispatched = it.totalGesturesDispatched + 1
                )
            }

            // 6. Check Accessibility Readiness
            if (!accessibilityController.isReady && activeSimulator == null) {
                _botState.update {
                    it.copy(statusMessage = "ACCESSIBILITY SERVICE NOT READY - Please enable in Settings")
                }
                return@launch
            }

            // 7. Dispatch Action
            dispatchPlannedAction(planned)

            // 8. Closed Loop: Wait and Verify
            delay(250)
            val afterBmp = getScreenBitmap()
            if (afterBmp != null) {
                val changed = gameStateManager.verifyActionEffect(afterBmp)
                if (!changed && gameStateManager.getConsecutiveMisses() >= 3) {
                    _botState.update {
                        it.copy(statusMessage = "Repeated action missed. Re-analyzing screen layout...")
                    }
                }
            }

            // 9. Stop if action is DONE
            if (planned.actionType == ActionType.DONE) {
                stopBot()
                _botState.update { it.copy(statusMessage = "✅ Game Goal Finished! (Done)") }
            }
        }
    }

    private fun dispatchPlannedAction(planned: PlannedAction) {
        vibrateFeedback()

        // Simulator override
        activeSimulator?.let { sim ->
            when (planned.actionType) {
                ActionType.TAP, ActionType.RETRY -> sim.onSimulatedTap(planned.startX.toFloat(), planned.startY.toFloat())
                ActionType.SWIPE, ActionType.SWIPE_UP, ActionType.SWIPE_DOWN,
                ActionType.SWIPE_LEFT, ActionType.SWIPE_RIGHT -> sim.onSimulatedSwipe(
                    planned.startX.toFloat(), planned.startY.toFloat(),
                    planned.endX.toFloat(), planned.endY.toFloat(), planned.durationMs
                )
                ActionType.DRAG -> sim.onSimulatedSwipe(
                    planned.startX.toFloat(), planned.startY.toFloat(),
                    planned.endX.toFloat(), planned.endY.toFloat(), planned.durationMs
                )
                else -> {}
            }
            return
        }

        // Real Accessibility Service
        accessibilityController.executeAction(planned) { result ->
            when (result) {
                is GestureResult.Success -> Log.d(TAG, "Gesture dispatched successfully: ${planned.actionType.label}")
                is GestureResult.Failure -> Log.e(TAG, "Gesture failed: ${result.reason}")
                is GestureResult.ServiceNotReady -> Log.w(TAG, "ACCESSIBILITY SERVICE NOT READY")
            }
        }
    }

    private suspend fun getScreenBitmap(): Bitmap? {
        // Priority 1: Direct MainActivity VirtualDisplay screen capture
        com.example.MainActivity.instance?.captureCurrentBitmap()?.let {
            return it
        }

        // Priority 2: MediaProjection real-time screen capture service
        com.example.service.ScreenCaptureService.instance?.captureLatestBitmap()?.let {
            return it
        }

        // Priority 3: Active in-app simulator
        activeSimulator?.let {
            return it.captureFrame()
        }

        // Priority 4: Accessibility screenshot
        var accessibilityBitmap: Bitmap? = null
        GameBotAccessibilityService.instance?.let { service ->
            var done = false
            service.captureActiveScreen { bmp ->
                accessibilityBitmap = bmp
                done = true
            }
            var waitCounter = 0
            while (!done && waitCounter < 20) {
                delay(50)
                waitCounter++
            }
        }
        if (accessibilityBitmap != null) {
            return accessibilityBitmap
        }

        return createFallbackDisplayBitmap()
    }

    private fun createFallbackDisplayBitmap(): Bitmap {
        val width = 720
        val height = 1280
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        canvas.drawColor(0xFF0F172A.toInt())

        val paint = android.graphics.Paint().apply {
            color = 0xFF00E5FF.toInt()
            textSize = 36f
            isAntiAlias = true
        }
        canvas.drawText("AI Game Bot Universal Canvas", 80f, 200f, paint)

        val targetPaint = android.graphics.Paint().apply {
            color = 0xFF00E676.toInt()
        }
        canvas.drawCircle(360f, 640f, 60f, targetPaint)

        return bitmap
    }

    private fun vibrateFeedback() {
        if (!_botConfig.value.vibrationFeedback) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(30)
            }
        } catch (e: Exception) {
            // Ignore vibration errors
        }
    }

    fun clearHistory() {
        _botState.update {
            it.copy(
                recentActions = emptyList(),
                currentStep = 0,
                lastAction = null,
                pendingStepAction = null,
                totalGesturesDispatched = 0,
                statusMessage = "History cleared"
            )
        }
    }
}

