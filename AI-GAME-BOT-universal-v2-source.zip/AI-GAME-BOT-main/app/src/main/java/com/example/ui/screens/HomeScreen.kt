package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.controller.GameBotController
import com.example.service.FloatingBotOverlayService
import com.example.ui.components.ActionHistoryItem
import com.example.ui.components.BotStatusCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonGreen

import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.ui.components.DebugBoundingBoxOverlay
import com.example.ui.components.ScreenCalibrationDialog

@Composable
fun HomeScreen(
    controller: GameBotController,
    onNavigateToArcade: () -> Unit,
    onToggleScreenCapture: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val botState by controller.botState.collectAsState()
    val botConfig by controller.botConfig.collectAsState()
    var showCalibrationDialog by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0B0F19))
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(Modifier.height(8.dp))
                // App Title Banner
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AI Game Bot",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Universal 2D Game AI • Auto Detect Engine",
                            color = CyberCyan,
                            fontSize = 12.sp
                        )
                    }

                    // In-App Arcade Shortcut
                    Button(
                        onClick = onNavigateToArcade,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.SportsEsports, contentDescription = null, Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Game Arcade", fontSize = 12.sp)
                    }
                }
            }

            // Live Bot Status HUD Card (With all 9 required metrics)
            item {
                BotStatusCard(
                    botState = botState,
                    maxSteps = botConfig.maxSteps
                )
            }

            // Universal Engine Action Toolbar (Auto Detect, 1 Step, Execute Step, Debug, Calibrate)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "🎮 UNIVERSAL AI CONTROLS",
                        color = Color(0xFF64748B),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // AUTO DETECT Toggle Chip
                        FilterChip(
                            selected = botConfig.targetGame == "Auto Detect",
                            onClick = {
                                controller.updateConfig {
                                    it.copy(
                                        targetGame = "Auto Detect",
                                        customGoal = "Dynamically inspect screen, detect game type and win objective"
                                    )
                                }
                            },
                            label = { Text("🤖 AUTO DETECT", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyan,
                                selectedLabelColor = Color(0xFF00363D),
                                containerColor = Color(0xFF131926),
                                labelColor = Color(0xFF94A3B8)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // DEBUG OVERLAY Toggle Chip
                        FilterChip(
                            selected = botConfig.isDebugOverlayEnabled,
                            onClick = {
                                controller.updateConfig {
                                    it.copy(isDebugOverlayEnabled = !it.isDebugOverlayEnabled)
                                }
                            },
                            label = { Text("🐞 DEBUG MODE", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFFFD600),
                                selectedLabelColor = Color(0xFF261E00),
                                containerColor = Color(0xFF131926),
                                labelColor = Color(0xFF94A3B8)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // CALIBRATE SCREEN Button
                        OutlinedButton(
                            onClick = { showCalibrationDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonGreen)
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null, Modifier.size(14.dp), tint = NeonGreen)
                            Spacer(Modifier.width(4.dp))
                            Text("CALIBRATE", fontSize = 11.sp)
                        }
                    }

                    // 1 STEP & EXECUTE STEP Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { controller.planSingleStepOnly() },
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E283D))
                        ) {
                            Icon(Icons.Default.SkipNext, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("1 STEP (Plan)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Button(
                            onClick = { controller.executePlannedStep() },
                            modifier = Modifier.weight(1f).height(44.dp),
                            enabled = botState.pendingStepAction != null,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonGreen,
                                disabledContainerColor = Color(0xFF1B2335)
                            )
                        ) {
                            Icon(
                                Icons.Default.PlayCircle,
                                contentDescription = null,
                                tint = if (botState.pendingStepAction != null) Color(0xFF003314) else Color(0xFF64748B),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "EXECUTE STEP",
                                color = if (botState.pendingStepAction != null) Color(0xFF003314) else Color(0xFF64748B),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Planned Step Alert Card if ready
                    botState.pendingStepAction?.let { planned ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF192A1A)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🎯", fontSize = 16.sp)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        text = "Planned: ${planned.actionType.label} @ (${planned.startX}, ${planned.startY})",
                                        color = NeonGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = "${planned.thought} (${planned.confidence.toInt()}% Confidence)",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Target Game & Strategy Selection Card
            item {
                com.example.ui.components.GameTargetSelectorCard(
                    config = botConfig,
                    onUpdateConfig = { update -> controller.updateConfig(update) }
                )
            }

            // Primary Action Controls (Continuous Bot Run)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Big Start / Stop Auto Bot Button
                    Button(
                        onClick = {
                            if (botState.isBotRunning) {
                                controller.stopBot()
                            } else {
                                controller.startBot()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (botState.isBotRunning) Color(0xFFFF5252) else CyberCyan
                        )
                    ) {
                        Icon(
                            if (botState.isBotRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = if (botState.isBotRunning) Color.White else Color(0xFF00363D)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = if (botState.isBotRunning) "STOP AI BOT (रोकें)" else "START AI BOT (बोट शुरू करें)",
                            color = if (botState.isBotRunning) Color.White else Color(0xFF00363D),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // MediaProjection Screen Capture Button
                        OutlinedButton(
                            onClick = onToggleScreenCapture,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = if (botState.isScreenCaptureActive) DangerRed else NeonGreen
                            )
                        ) {
                            Icon(
                                if (botState.isScreenCaptureActive) Icons.Default.VideocamOff else Icons.Default.Videocam,
                                contentDescription = null,
                                tint = if (botState.isScreenCaptureActive) DangerRed else NeonGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                if (botState.isScreenCaptureActive) "Stop Cap" else "Screen Cap",
                                fontSize = 11.sp
                            )
                        }

                        // Floating Overlay Button
                        OutlinedButton(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                } else {
                                    FloatingBotOverlayService.start(context)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.Layers, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("HUD", fontSize = 11.sp)
                        }
                    }
                }
            }

        // Android System Permission Status Cards
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "सिस्टम परमिशन व सेटअप (Phone Integration)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(10.dp))

                    // MediaProjection Screen Capture Setup
                    PermissionRow(
                        title = "MediaProjection Screen Capture",
                        subtitle = if (botState.isScreenCaptureActive) "लाइव स्क्रीन कैप्चर सक्रिय है - AI रियल-टाइम देख रहा है" else "AI को गेम स्क्रीन लाइव भेजने के लिए शुरू करें",
                        isGranted = botState.isScreenCaptureActive,
                        actionLabel = if (botState.isScreenCaptureActive) "Stop" else "Start Capture",
                        onAction = onToggleScreenCapture
                    )

                    Spacer(Modifier.height(8.dp))

                    // Accessibility Service
                    PermissionRow(
                        title = "Accessibility Gesture Service",
                        subtitle = "गेम में ऑटोमैटिक टैप व स्वाइप करने के लिए",
                        isGranted = botState.isAccessibilityEnabled,
                        actionLabel = "Enable",
                        onAction = {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            context.startActivity(intent)
                        }
                    )

                    Spacer(Modifier.height(8.dp))

                    // Overlay Window
                    val hasOverlay = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)
                    PermissionRow(
                        title = "Floating Overlay (डिस्प्ले ओवर ऐप्स)",
                        subtitle = "गेम के ऊपर फ़्लोटिंग कंट्रोल बार दिखाने के लिए",
                        isGranted = hasOverlay,
                        actionLabel = "Enable",
                        onAction = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            }
                        }
                    )
                }
            }
        }

        // Live Action History Feed
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "लाइव एक्शन इतिहास (${botState.recentActions.size})",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )

                if (botState.recentActions.isNotEmpty()) {
                    Button(
                        onClick = { controller.clearHistory() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                    ) {
                        Text("Clear", color = CyberCyan, fontSize = 12.sp)
                    }
                }
            }
        }

        if (botState.recentActions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "अभी तक कोई एक्शन नहीं लिया गया। 'START AI BOT' या '1 Step' दबाएं।",
                        color = Color(0xFF64748B),
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(botState.recentActions.reversed()) { action ->
                ActionHistoryItem(action = action)
            }
        }

        item {
            Spacer(Modifier.height(24.dp))
        }
    }

    // Visual Bounding Box Debug Overlay
    if (botConfig.isDebugOverlayEnabled) {
        DebugBoundingBoxOverlay(
            state = botState.debugOverlayState,
            modifier = Modifier.fillMaxSize()
        )
    }

    // Screen Calibration Dialog
    if (showCalibrationDialog) {
        ScreenCalibrationDialog(
            controller = controller,
            currentProfile = botState.calibrationProfile,
            onDismiss = { showCalibrationDialog = false }
        )
    }
    } // closes Box
} // closes HomeScreen

@Composable
fun PermissionRow(
    title: String,
    subtitle: String,
    isGranted: Boolean,
    actionLabel: String = "Enable",
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0F1420))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(subtitle, color = Color(0xFF94A3B8), fontSize = 11.sp)
        }

        Spacer(Modifier.width(8.dp))

        if (isGranted && actionLabel == "Enable") {
            Icon(Icons.Default.CheckCircle, contentDescription = "Active", tint = NeonGreen, modifier = Modifier.size(20.dp))
        } else {
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGranted) DangerRed else Color(0xFF263238)
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = actionLabel,
                    color = if (isGranted) Color.White else CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
