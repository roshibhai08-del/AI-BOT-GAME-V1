package com.example.engine

import android.graphics.Bitmap
import com.example.model.GameCategory

data class ClassificationResult(
    val category: GameCategory,
    val confidence: Float,
    val detectedGameTitle: String,
    val isUnknownFallback: Boolean
)

class GameClassifier {

    /**
     * Dynamically classifies the game based on visual features, text keywords, and object patterns.
     * NEVER assumes a hardcoded game or defaults to "Obstacle Runner".
     */
    fun classify(
        bitmap: Bitmap?,
        detectedTextList: List<String>,
        explicitTarget: String = "Auto Detect"
    ): ClassificationResult {
        // If user manually chose a target and it's not "Auto Detect", prioritize user preference
        if (explicitTarget.isNotBlank() && explicitTarget != "Auto Detect") {
            val matchedCategory = matchTargetStringToCategory(explicitTarget)
            return ClassificationResult(
                category = matchedCategory,
                confidence = 0.95f,
                detectedGameTitle = explicitTarget,
                isUnknownFallback = false
            )
        }

        val allText = detectedTextList.joinToString(" ").lowercase()

        // 1. Math / Quiz / Educational check
        if (allText.contains("²") || allText.contains("³") || allText.contains("^") ||
            allText.contains("√") || allText.contains("+") || allText.contains("-") ||
            allText.contains("math") || allText.contains("quiz") || allText.contains("calculate") ||
            allText.contains("mathgro") || allText.contains("7²") || allText.contains("7^2")
        ) {
            return ClassificationResult(GameCategory.MATH_QUIZ, 0.98f, "Math / Quiz", false)
        }

        // 2. Chess / Checkers
        if (allText.contains("chess") || allText.contains("checkmate") || allText.contains("king") && allText.contains("queen")) {
            return ClassificationResult(GameCategory.CHESS, 0.90f, "Chess Game", false)
        }

        // 3. Ludo / Board
        if (allText.contains("ludo") || allText.contains("dice") || allText.contains("roll")) {
            return ClassificationResult(GameCategory.LUDO, 0.90f, "Ludo King / Board Game", false)
        }

        // 4. Match-3 / Candy
        if (allText.contains("candy") || allText.contains("match 3") || allText.contains("crush") || allText.contains("jelly")) {
            return ClassificationResult(GameCategory.MATCH_3, 0.91f, "Match-3 / Puzzle", false)
        }

        // 5. Tile 2048 / Number Puzzle
        if (allText.contains("2048") || allText.contains("tile") || (allText.contains("merge") && allText.contains("numbers"))) {
            return ClassificationResult(GameCategory.TILE_GAME, 0.89f, "Tile 2048 / Number Game", false)
        }

        // 6. Word / Trivia Game
        if (allText.contains("word") || allText.contains("anagram") || allText.contains("crossword") || allText.contains("trivia")) {
            return ClassificationResult(GameCategory.WORD_GAME, 0.88f, "Word / Trivia Game", false)
        }

        // 7. Card Game
        if (allText.contains("solitaire") || allText.contains("poker") || allText.contains("card") || allText.contains("deck")) {
            return ClassificationResult(GameCategory.CARD_GAME, 0.88f, "Card Game", false)
        }

        // 8. Racing
        if (allText.contains("racing") || allText.contains("car") || allText.contains("drift") || allText.contains("speed")) {
            return ClassificationResult(GameCategory.RACING, 0.86f, "Racing Game", false)
        }

        // 9. Runner (only if explicit runner keywords exist)
        if (allText.contains("subway") || allText.contains("temple run") || allText.contains("endless runner") || allText.contains("dodge")) {
            return ClassificationResult(GameCategory.RUNNER, 0.88f, "Endless Runner", false)
        }

        // 10. Platformer / Shooter
        if (allText.contains("mario") || allText.contains("platformer") || allText.contains("jump")) {
            return ClassificationResult(GameCategory.PLATFORMER, 0.85f, "2D Platformer", false)
        }

        if (allText.contains("shooter") || allText.contains("bullet") || allText.contains("target")) {
            return ClassificationResult(GameCategory.SHOOTER_2D, 0.85f, "2D Target Shooter", false)
        }

        // If no explicit category matches:
        // Do NOT guess or default to Obstacle Runner!
        // Return UNKNOWN and engage GENERAL VISUAL GAMEPLAY MODE.
        return ClassificationResult(
            category = GameCategory.UNKNOWN,
            confidence = 0.50f,
            detectedGameTitle = "Unknown 2D Game (General Visual Mode)",
            isUnknownFallback = true
        )
    }

    private fun matchTargetStringToCategory(target: String): GameCategory {
        val lower = target.lowercase()
        return when {
            lower.contains("math") || lower.contains("quiz") -> GameCategory.MATH_QUIZ
            lower.contains("match") || lower.contains("candy") -> GameCategory.MATCH_3
            lower.contains("subway") || lower.contains("temple") || lower.contains("runner") -> GameCategory.RUNNER
            lower.contains("2048") || lower.contains("tile") -> GameCategory.TILE_GAME
            lower.contains("chess") -> GameCategory.CHESS
            lower.contains("ludo") -> GameCategory.LUDO
            lower.contains("racing") || lower.contains("climb") -> GameCategory.RACING
            lower.contains("card") || lower.contains("solitaire") -> GameCategory.CARD_GAME
            lower.contains("puzzle") -> GameCategory.PUZZLE
            else -> GameCategory.UNKNOWN
        }
    }
}
