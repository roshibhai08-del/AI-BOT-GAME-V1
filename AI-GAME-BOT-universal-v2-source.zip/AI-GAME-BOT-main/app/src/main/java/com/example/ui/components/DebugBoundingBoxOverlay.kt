package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DebugOverlayState
import com.example.model.ObjectType

@Composable
fun DebugBoundingBoxOverlay(
    state: DebugOverlayState,
    modifier: Modifier = Modifier
) {
    if (!state.isDebugEnabled) return

    Box(modifier = modifier.fillMaxSize()) {
        // 1. Canvas for visual bounding boxes and action crosshair
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = size.width
            val canvasH = size.height

            // Draw bounding boxes for detected objects
            for (obj in state.detectedObjects) {
                val boxColor = Color(obj.colorHex)
                val left = obj.bounds.left * canvasW
                val top = obj.bounds.top * canvasH
                val right = obj.bounds.right * canvasW
                val bottom = obj.bounds.bottom * canvasH
                val boxWidth = (right - left).coerceAtLeast(10f)
                val boxHeight = (bottom - top).coerceAtLeast(10f)

                // Outline
                drawRect(
                    color = boxColor,
                    topLeft = Offset(left, top),
                    size = Size(boxWidth, boxHeight),
                    style = Stroke(width = 3f)
                )

                // Fill with subtle transparency
                drawRect(
                    color = boxColor.copy(alpha = 0.15f),
                    topLeft = Offset(left, top),
                    size = Size(boxWidth, boxHeight)
                )
            }

            // Draw Yellow Crosshair at Intended Action Coordinate
            val planned = state.plannedAction
            if (planned != null && planned.startX > 0 && planned.startY > 0) {
                // Scale physical coords to current canvas
                val crosshairX = if (state.crosshairX > 0) (state.crosshairX / 1080f) * canvasW else (planned.startX / 1080f) * canvasW
                val crosshairY = if (state.crosshairY > 0) (state.crosshairY / 2400f) * canvasH else (planned.startY / 2400f) * canvasH
                val crosshairColor = Color(0xFFFFD600) // Vibrant Yellow

                // Circle target
                drawCircle(
                    color = crosshairColor,
                    radius = 28f,
                    center = Offset(crosshairX, crosshairY),
                    style = Stroke(width = 4f)
                )
                drawCircle(
                    color = crosshairColor.copy(alpha = 0.3f),
                    radius = 28f,
                    center = Offset(crosshairX, crosshairY)
                )
                // Cross lines
                drawLine(
                    color = crosshairColor,
                    start = Offset(crosshairX - 45f, crosshairY),
                    end = Offset(crosshairX + 45f, crosshairY),
                    strokeWidth = 3f
                )
                drawLine(
                    color = crosshairColor,
                    start = Offset(crosshairX, crosshairY - 45f),
                    end = Offset(crosshairX, crosshairY + 45f),
                    strokeWidth = 3f
                )
            }
        }

        // 2. Telemetry HUD Card
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(8.dp)
                .background(Color(0xE6080E1A), RoundedCornerShape(12.dp))
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DEBUG HUD",
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "🟢 Target | 🔴 Obstacle | 🔵 Player | 🟡 Tap Crosshair",
                    color = Color(0xFF94A3B8),
                    fontSize = 9.sp
                )
            }

            Spacer(Modifier.height(4.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Game: ${state.detectedGame}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    Text("Type: ${state.gameCategory.displayName}", color = Color(0xFF38BDF8), fontSize = 10.sp)
                    Text("Level: ${state.currentLevel} • State: ${state.currentState.label}", color = Color(0xFFA5B4FC), fontSize = 9.sp)
                }
                Column(modifier = Modifier.weight(1f)) {
                    val planned = state.plannedAction
                    Text("Action: ${planned?.actionType?.label ?: "WAIT"}", color = Color(0xFFFFD600), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Coords: (${planned?.startX ?: 0}, ${planned?.startY ?: 0})", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("Confidence: ${state.confidenceScore.toInt()}%", color = if (state.confidenceScore >= 60) Color(0xFF00E676) else Color(0xFFFF5252), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(4.dp))
            Text(
                text = "Objective: ${state.objective}",
                color = Color(0xFFE2E8F0),
                fontSize = 9.sp
            )
            Text(
                text = "Verification: ${state.lastVerificationResult}",
                color = Color(0xFF94A3B8),
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
