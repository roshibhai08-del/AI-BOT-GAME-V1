package com.example.engine

import android.graphics.RectF
import com.example.model.DetectedObject
import com.example.model.ObjectType

data class VictoryInfo(
    val isVictoryDetected: Boolean,
    val bannerText: String = "",
    val nextButtonBounds: RectF? = null
)

class VictoryDetector {

    private val victoryKeywords = listOf(
        "level complete", "stage clear", "you win", "victory",
        "well done", "mission accomplished", "3 stars", "congratulations"
    )

    private val nextButtonKeywords = listOf(
        "next", "continue", "claim", "proceed", "keep playing", "ok"
    )

    fun checkVictory(detectedTexts: List<String>, objects: List<DetectedObject>): VictoryInfo {
        val allText = detectedTexts.joinToString(" ").lowercase()
        val isVictory = victoryKeywords.any { allText.contains(it) }

        if (!isVictory) {
            return VictoryInfo(isVictoryDetected = false)
        }

        // Search for Next/Continue CTA button
        var nextBounds: RectF? = null
        for (obj in objects) {
            val labelLower = obj.label.lowercase()
            if (nextButtonKeywords.any { labelLower.contains(it) }) {
                nextBounds = obj.bounds
                break
            }
        }

        // If no explicit Next button detected in objects, provide standard bottom-center CTA location
        if (nextBounds == null) {
            nextBounds = RectF(0.25f, 0.75f, 0.75f, 0.88f)
        }

        return VictoryInfo(
            isVictoryDetected = true,
            bannerText = "Victory / Level Complete Detected",
            nextButtonBounds = nextBounds
        )
    }
}
