package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActionType
import com.example.model.BotAction
import com.example.model.BotState
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonGreen

@Composable
fun BotStatusCard(
    botState: BotState,
    maxSteps: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Row 1: Bot Status & Screen/Accessibility Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val statusColor = when {
                        botState.isBotRunning && !botState.isPaused -> NeonGreen
                        botState.isPaused -> NeonAmber
                        botState.isStepMode -> CyberCyan
                        else -> Color(0xFF64748B)
                    }

                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = when {
                            botState.isBotRunning && !botState.isPaused -> "BOT ACTIVE"
                            botState.isPaused -> "BOT PAUSED"
                            botState.isStepMode -> "1 STEP READY"
                            else -> "BOT STANDBY"
                        },
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                // Screen Capture & Accessibility Badges
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (botState.isScreenCaptureActive) NeonGreen.copy(alpha = 0.2f) else DangerRed.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (botState.isScreenCaptureActive) "CAP ON" else "CAP OFF",
                            color = if (botState.isScreenCaptureActive) NeonGreen else DangerRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (botState.isAccessibilityEnabled) CyberCyan.copy(alpha = 0.2f) else DangerRed.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (botState.isAccessibilityEnabled) "ACC ON" else "ACC OFF",
                            color = if (botState.isAccessibilityEnabled) CyberCyan else DangerRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Row 2: Detected Game & Category
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = botState.currentGameName,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1E283D))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = botState.gameCategory.displayName,
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Row 3: Grid of Telemetry (Objective, Action, Confidence, Level, Progress)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0B0F19))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("🎯 OBJECTIVE:", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(botState.currentObjective, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("⚡ CURRENT ACTION:", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    val actionName = botState.pendingStepAction?.actionType?.label
                        ?: botState.lastAction?.action?.label
                        ?: "WAITING"
                    Text(actionName, color = Color(0xFFFFD600), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("📊 CONFIDENCE:", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    val conf = botState.confidenceScore.toInt()
                    val confColor = if (conf >= 60) NeonGreen else if (conf >= 40) NeonAmber else DangerRed
                    Text("$conf%", color = confColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("🏆 LEVEL & PROGRESS:", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("${botState.currentLevel} • Step ${botState.currentStep}/$maxSteps", color = CyberCyan, fontSize = 11.sp)
                }
            }

            Spacer(Modifier.height(8.dp))

            // Status message
            Text(
                text = "💬 ${botState.statusMessage}",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}

@Composable
fun ActionHistoryItem(
    action: BotAction,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Step Number Badge
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E283D)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "#${action.stepNumber}",
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${action.game} (${action.genre})",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = action.action.name,
                        color = when (action.action) {
                            ActionType.TAP, ActionType.DOUBLE_TAP, ActionType.LONG_PRESS -> CyberCyan
                            ActionType.SWIPE, ActionType.SWIPE_UP, ActionType.SWIPE_DOWN,
                            ActionType.SWIPE_LEFT, ActionType.SWIPE_RIGHT, ActionType.DRAG, ActionType.DROP -> ElectricPurple
                            ActionType.WAIT, ActionType.PAUSE, ActionType.RESUME -> NeonAmber
                            ActionType.BACK -> DangerRed
                            ActionType.DONE -> NeonGreen
                            else -> CyberCyan
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Spacer(Modifier.height(4.dp))
                Text(
                    text = action.thought,
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    maxLines = 2
                )

                Spacer(Modifier.height(4.dp))
                Text(
                    text = action.toActionString(),
                    color = Color(0xFF64748B),
                    fontSize = 11.sp
                )
            }
        }
    }
}
