package com.example.engine

import android.graphics.Bitmap
import android.graphics.Color
import com.example.model.GameCategory
import com.example.model.GameStateStatus
import com.example.model.PlannedAction

class GameStateManager {

    var currentStatus: GameStateStatus = GameStateStatus.DISCOVERY
        private set

    var currentCategory: GameCategory = GameCategory.UNKNOWN
        private set

    var currentLevel: String = "Level 1"
        private set

    private var previousFrameHash: Long = 0L
    private var lastAction: PlannedAction? = null
    private var identicalFrameCount: Int = 0

    // Callback when game switch is detected
    var onGameSwitchDetected: (() -> Unit)? = null

    /**
     * Checks if the screen has drastically changed, indicating a new game was launched
     * or app switched. If so, triggers game switch reset.
     */
    fun processFrame(bitmap: Bitmap): Boolean {
        val currentHash = computePerceptualHash(bitmap)
        val hashDiff = Math.abs(currentHash - previousFrameHash)

        // If the screen changed drastically (> 75% visual shift), check for game switch
        var isGameSwitched = false
        if (previousFrameHash != 0L && hashDiff > 5000000L) {
            // Significant transition detected
            isGameSwitched = true
            resetSession()
            onGameSwitchDetected?.invoke()
        }

        previousFrameHash = currentHash
        return isGameSwitched
    }

    /**
     * Evaluates closed-loop feedback: Did the last action cause the expected screen change?
     */
    fun verifyActionEffect(newBitmap: Bitmap): Boolean {
        val action = lastAction ?: return true
        val newHash = computePerceptualHash(newBitmap)
        val delta = Math.abs(newHash - previousFrameHash)

        return if (delta < 5000L) {
            // Screen barely changed — possible missed tap or stuck screen
            identicalFrameCount++
            false
        } else {
            identicalFrameCount = 0
            true
        }
    }

    fun recordAction(action: PlannedAction) {
        lastAction = action
    }

    fun updateStatus(status: GameStateStatus) {
        currentStatus = status
    }

    fun updateCategory(category: GameCategory) {
        currentCategory = category
    }

    fun updateLevel(level: String) {
        currentLevel = level
    }

    fun getConsecutiveMisses(): Int = identicalFrameCount

    fun resetSession() {
        currentStatus = GameStateStatus.DISCOVERY
        currentCategory = GameCategory.UNKNOWN
        currentLevel = "Level 1"
        previousFrameHash = 0L
        lastAction = null
        identicalFrameCount = 0
    }

    /**
     * Fast downsampled perceptual hash computation for screen change detection.
     */
    private fun computePerceptualHash(bitmap: Bitmap): Long {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return 0L

        var sum = 0L
        val stepX = (w / 8).coerceAtLeast(1)
        val stepY = (h / 8).coerceAtLeast(1)

        for (y in 0 until h step stepY) {
            for (x in 0 until w step stepX) {
                val pixel = bitmap.getPixel(x, y)
                val lum = (Color.red(pixel) * 299 + Color.green(pixel) * 587 + Color.blue(pixel) * 114) / 1000
                sum = (sum * 31) + lum
            }
        }
        return sum
    }
}
