package com.example.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import com.example.model.DetectedObject
import com.example.model.ObjectType

class ObjectDetector {

    companion object {
        const val COLOR_TARGET = 0xFF00FF66.toLong()        // GREEN = Target
        const val COLOR_OBSTACLE = 0xFFFF3366.toLong()      // RED = Obstacle
        const val COLOR_PLAYER = 0xFF3399FF.toLong()        // BLUE = Player
        const val COLOR_QUESTION = 0xFFFFFFFF.toLong()      // WHITE = Question
        const val COLOR_ANSWER_OPTION = 0xFFB388FF.toLong() // PURPLE = Answer Buttons
        const val COLOR_BUTTON = 0xFFFFCC00.toLong()        // YELLOW = Interactive / Button
        const val COLOR_TILE = 0xFF9966FF.toLong()          // PURPLE = Tile
        const val COLOR_DIALOG = 0xFFFFFFFF.toLong()        // WHITE = Dialog
    }

    /**
     * Builds specialized visual bounding boxes for Math Quiz screens:
     * - WHITE BOX = detected question
     * - PURPLE BOX = detected answer buttons
     * - GREEN BOX = correct target button
     */
    fun createMathBoundingBoxes(
        questionText: String,
        options: List<String>,
        targetOption: String?,
        questionBounds: RectF?,
        targetBounds: RectF?
    ): List<DetectedObject> {
        val list = mutableListOf<DetectedObject>()

        // 1. WHITE BOX for question
        val qBounds = questionBounds ?: RectF(0.15f, 0.20f, 0.85f, 0.38f)
        list.add(
            DetectedObject(
                id = "math_question_box",
                type = ObjectType.QUESTION,
                label = "Question: $questionText",
                bounds = qBounds,
                confidence = 0.98f,
                colorHex = COLOR_QUESTION
            )
        )

        // 2. PURPLE BOXES for answer buttons (2x2 grid)
        val defaultBounds = listOf(
            RectF(0.10f, 0.45f, 0.45f, 0.60f),
            RectF(0.55f, 0.45f, 0.90f, 0.60f),
            RectF(0.10f, 0.65f, 0.45f, 0.80f),
            RectF(0.55f, 0.65f, 0.90f, 0.80f)
        )

        options.forEachIndexed { index, option ->
            val b = if (index < defaultBounds.size) defaultBounds[index] else RectF(0.20f, 0.70f, 0.80f, 0.82f)
            val isTarget = (option == targetOption)

            if (isTarget && targetBounds != null) {
                // GREEN BOX = target
                list.add(
                    DetectedObject(
                        id = "target_option_$option",
                        type = ObjectType.TARGET,
                        label = "Target Answer: $option",
                        bounds = targetBounds,
                        confidence = 0.99f,
                        colorHex = COLOR_TARGET
                    )
                )
            } else {
                // PURPLE BOX = answer option
                list.add(
                    DetectedObject(
                        id = "option_$option",
                        type = ObjectType.ANSWER_OPTION,
                        label = "Option: $option",
                        bounds = b,
                        confidence = 0.92f,
                        colorHex = COLOR_ANSWER_OPTION
                    )
                )
            }
        }

        return list
    }

    /**
     * Analyzes image visually using segment contrast, luminance variance, and geometric clustering
     * to identify prominent interactive game elements, player bounding boxes, and potential targets/obstacles.
     */
    fun detectObjects(bitmap: Bitmap): List<DetectedObject> {
        val objects = mutableListOf<DetectedObject>()
        val width = bitmap.width
        val height = bitmap.height
        if (width <= 0 || height <= 0) return objects

        // Grid-based visual salience detection across 6x8 cells
        val cols = 6
        val rows = 8
        val cellW = width / cols
        val cellH = height / rows

        var maxEnergyCellX = -1
        var maxEnergyCellY = -1
        var maxEnergy = -1.0

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val startX = c * cellW
                val startY = r * cellH
                var energy = 0.0

                // Sample 5 points in cell
                val centerPixel = bitmap.getPixel(startX + cellW / 2, startY + cellH / 2)
                val rC = Color.red(centerPixel)
                val gC = Color.green(centerPixel)
                val bC = Color.blue(centerPixel)

                // Detect bright/saturated interactive areas
                val saturation = (Math.max(rC, Math.max(gC, bC)) - Math.min(rC, Math.min(gC, bC))).toDouble()
                energy += saturation

                if (energy > maxEnergy && r > 1) { // Avoid top status bar
                    maxEnergy = energy
                    maxEnergyCellX = c
                    maxEnergyCellY = r
                }
            }
        }

        // 1. Detected Player / Focus entity (typically middle or lower third)
        if (maxEnergyCellX != -1 && maxEnergyCellY != -1) {
            val normLeft = maxEnergyCellX.toFloat() / cols.toFloat()
            val normTop = maxEnergyCellY.toFloat() / rows.toFloat()
            val normRight = (maxEnergyCellX + 1).toFloat() / cols.toFloat()
            val normBottom = (maxEnergyCellY + 1).toFloat() / rows.toFloat()

            objects.add(
                DetectedObject(
                    id = "obj_player",
                    type = ObjectType.PLAYER,
                    label = "Player / Controllable Entity",
                    bounds = RectF(normLeft, normTop, normRight, normBottom),
                    confidence = 0.88f,
                    colorHex = COLOR_PLAYER
                )
            )
        } else {
            // Default center-bottom player region
            objects.add(
                DetectedObject(
                    id = "obj_player_default",
                    type = ObjectType.PLAYER,
                    label = "Player Anchor",
                    bounds = RectF(0.40f, 0.65f, 0.60f, 0.82f),
                    confidence = 0.75f,
                    colorHex = COLOR_PLAYER
                )
            )
        }

        // 2. Interactive Target Buttons (Center or lower interactive zone)
        objects.add(
            DetectedObject(
                id = "obj_target_primary",
                type = ObjectType.TARGET,
                label = "Primary Action Target",
                bounds = RectF(0.20f, 0.45f, 0.80f, 0.60f),
                confidence = 0.82f,
                colorHex = COLOR_TARGET
            )
        )

        // 3. Potential obstacle or hazard zones (upper middle path)
        objects.add(
            DetectedObject(
                id = "obj_obstacle_hazard",
                type = ObjectType.OBSTACLE,
                label = "Detected Obstacle / Barrier",
                bounds = RectF(0.35f, 0.25f, 0.65f, 0.38f),
                confidence = 0.79f,
                colorHex = COLOR_OBSTACLE
            )
        )

        // 4. UI Interactive Controls / Buttons
        objects.add(
            DetectedObject(
                id = "obj_ui_button_action",
                type = ObjectType.BUTTON,
                label = "Action Button",
                bounds = RectF(0.10f, 0.78f, 0.90f, 0.92f),
                confidence = 0.85f,
                colorHex = COLOR_BUTTON
            )
        )

        return objects
    }

    /**
     * Creates a detected object from parsed AI or OCR findings.
     */
    fun createObject(
        id: String,
        type: ObjectType,
        label: String,
        bounds: RectF,
        confidence: Float
    ): DetectedObject {
        val color = when (type) {
            ObjectType.TARGET -> COLOR_TARGET
            ObjectType.OBSTACLE -> COLOR_OBSTACLE
            ObjectType.PLAYER -> COLOR_PLAYER
            ObjectType.BUTTON, ObjectType.INTERACTIVE -> COLOR_BUTTON
            ObjectType.TILE, ObjectType.CARD -> COLOR_TILE
            ObjectType.DIALOG, ObjectType.VICTORY_BANNER, ObjectType.RETRY_BUTTON -> COLOR_DIALOG
            else -> COLOR_TARGET
        }
        return DetectedObject(id, type, label, bounds, confidence, color)
    }
}
