package com.example.engine

import android.graphics.Bitmap
import com.example.model.IdentitySource

data class GameIdentity(
    val gameName: String,
    val packageName: String = "",
    val source: IdentitySource = IdentitySource.INFERENCE,
    val confidence: Float = 0.95f
)

class GameIdentityDetector(
    private val foregroundAppDetector: ForegroundAppDetector,
    private val ocrManager: OCRManager
) {

    private var persistentIdentity: GameIdentity? = null

    /**
     * Resolves the actual game identity using the prioritized 5-tier detection pipeline.
     */
    fun detectIdentity(
        bitmap: Bitmap?,
        detectedTexts: List<String>,
        simulatedPackage: String? = null
    ): GameIdentity {
        // METHOD 1 & 2: Foreground App Detection via Package & App Label
        val foregroundApp = foregroundAppDetector.detectForegroundApp(simulatedPackage)
        if (foregroundApp != null && foregroundApp.appLabel.isNotBlank()) {
            val identity = GameIdentity(
                gameName = foregroundApp.appLabel,
                packageName = foregroundApp.packageName,
                source = IdentitySource.APP_LABEL,
                confidence = 0.98f
            )
            persistentIdentity = identity
            return identity
        } else if (foregroundApp != null && foregroundApp.packageName.isNotBlank()) {
            val identity = GameIdentity(
                gameName = foregroundApp.packageName,
                packageName = foregroundApp.packageName,
                source = IdentitySource.PACKAGE,
                confidence = 0.92f
            )
            persistentIdentity = identity
            return identity
        }

        // METHOD 3: OCR on visible game title / header / logo text
        val titleFromOcr = extractTitleFromOcr(detectedTexts)
        if (titleFromOcr != null) {
            val identity = GameIdentity(
                gameName = titleFromOcr,
                packageName = "",
                source = IdentitySource.OCR,
                confidence = 0.90f
            )
            persistentIdentity = identity
            return identity
        }

        // METHOD 4: Visual heuristics (Check for distinctive game layouts)
        val visualName = checkVisualLayoutName(detectedTexts)
        if (visualName != null) {
            val identity = GameIdentity(
                gameName = visualName,
                packageName = "",
                source = IdentitySource.VISUAL,
                confidence = 0.85f
            )
            persistentIdentity = identity
            return identity
        }

        // METHOD 5: Persistent game identity from current session if still same game
        if (persistentIdentity != null) {
            return persistentIdentity!!.copy(
                source = IdentitySource.INFERENCE,
                confidence = 0.80f
            )
        }

        // Reliable name cannot be determined:
        // Do NOT falsely invent a name. Show "Unidentified Game"
        return GameIdentity(
            gameName = "Unidentified Game",
            packageName = "",
            source = IdentitySource.INFERENCE,
            confidence = 0.40f
        )
    }

    private fun extractTitleFromOcr(texts: List<String>): String? {
        val allText = texts.joinToString(" ").lowercase()
        // Known games and common Android title patterns
        val knownTitles = listOf(
            "MathGro" to "MathGro",
            "Subway Surfers" to "Subway Surfers",
            "Chess" to "Chess",
            "Ludo King" to "Ludo King",
            "Candy Crush" to "Candy Crush Saga",
            "Temple Run" to "Temple Run",
            "2048" to "2048",
            "Hill Climb Racing" to "Hill Climb Racing",
            "Sudoku" to "Sudoku",
            "Wordle" to "Wordle"
        )

        for ((keyword, canonicalName) in knownTitles) {
            if (allText.contains(keyword.lowercase())) {
                return canonicalName
            }
        }

        // Check top header text elements (often line 1 or 2)
        val firstCandidate = texts.firstOrNull { it.length in 4..25 && !it.contains("?") && !it.contains("=") && !it.contains("Score") }
        return firstCandidate
    }

    private fun checkVisualLayoutName(texts: List<String>): String? {
        val joined = texts.joinToString(" ")
        return when {
            joined.contains("²") || joined.contains("7²") || joined.contains("Math") -> "MathGro"
            joined.contains("checkmate", ignoreCase = true) -> "Chess"
            joined.contains("dice", ignoreCase = true) -> "Ludo"
            else -> null
        }
    }

    fun reset() {
        persistentIdentity = null
    }
}
