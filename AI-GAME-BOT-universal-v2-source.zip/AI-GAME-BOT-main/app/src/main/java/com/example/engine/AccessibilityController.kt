package com.example.engine

import android.util.Log
import com.example.model.ActionType
import com.example.model.PlannedAction
import com.example.service.GameBotAccessibilityService
import kotlinx.coroutines.flow.StateFlow

sealed class GestureResult {
    data class Success(val action: PlannedAction) : GestureResult()
    data class Failure(val reason: String) : GestureResult()
    object ServiceNotReady : GestureResult()
}

class AccessibilityController {

    companion object {
        private const val TAG = "AccessibilityController"
    }

    val isServiceActiveFlow: StateFlow<Boolean>
        get() = GameBotAccessibilityService.isServiceActive

    val isReady: Boolean
        get() = GameBotAccessibilityService.instance != null && GameBotAccessibilityService.isServiceActive.value

    fun executeAction(
        action: PlannedAction,
        onComplete: (GestureResult) -> Unit
    ) {
        val service = GameBotAccessibilityService.instance
        if (service == null || !GameBotAccessibilityService.isServiceActive.value) {
            Log.w(TAG, "ACCESSIBILITY SERVICE NOT READY - cannot dispatch gesture")
            onComplete(GestureResult.ServiceNotReady)
            return
        }

        when (action.actionType) {
            ActionType.TAP, ActionType.RETRY -> {
                service.performTap(action.startX.toFloat(), action.startY.toFloat()) { success ->
                    if (success) onComplete(GestureResult.Success(action))
                    else onComplete(GestureResult.Failure("Tap gesture cancelled or failed"))
                }
            }

            ActionType.DOUBLE_TAP -> {
                service.performDoubleTap(action.startX.toFloat(), action.startY.toFloat()) { success ->
                    if (success) onComplete(GestureResult.Success(action))
                    else onComplete(GestureResult.Failure("Double Tap failed"))
                }
            }

            ActionType.LONG_PRESS -> {
                service.performLongPress(action.startX.toFloat(), action.startY.toFloat(), action.durationMs) { success ->
                    if (success) onComplete(GestureResult.Success(action))
                    else onComplete(GestureResult.Failure("Long Press failed"))
                }
            }

            ActionType.SWIPE, ActionType.SWIPE_UP, ActionType.SWIPE_DOWN,
            ActionType.SWIPE_LEFT, ActionType.SWIPE_RIGHT -> {
                service.performSwipe(
                    action.startX.toFloat(),
                    action.startY.toFloat(),
                    action.endX.toFloat(),
                    action.endY.toFloat(),
                    action.durationMs
                ) { success ->
                    if (success) onComplete(GestureResult.Success(action))
                    else onComplete(GestureResult.Failure("Swipe gesture failed"))
                }
            }

            ActionType.DRAG -> {
                service.performDrag(
                    action.startX.toFloat(),
                    action.startY.toFloat(),
                    action.endX.toFloat(),
                    action.endY.toFloat(),
                    action.durationMs
                ) { success ->
                    if (success) onComplete(GestureResult.Success(action))
                    else onComplete(GestureResult.Failure("Drag gesture failed"))
                }
            }

            ActionType.BACK -> {
                val success = service.performBack()
                if (success) onComplete(GestureResult.Success(action))
                else onComplete(GestureResult.Failure("Back gesture failed"))
            }

            ActionType.WAIT, ActionType.PAUSE, ActionType.RESUME, ActionType.DONE, ActionType.DROP -> {
                onComplete(GestureResult.Success(action))
            }
        }
    }
}
