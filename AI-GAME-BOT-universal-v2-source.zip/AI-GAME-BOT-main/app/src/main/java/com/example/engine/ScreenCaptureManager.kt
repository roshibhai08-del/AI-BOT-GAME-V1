package com.example.engine

import android.graphics.Bitmap
import com.example.service.ScreenCaptureService
import kotlinx.coroutines.flow.StateFlow

class ScreenCaptureManager {

    val isCapturingFlow: StateFlow<Boolean>
        get() = ScreenCaptureService.isCapturing

    val isCapturing: Boolean
        get() = ScreenCaptureService.isCapturing.value

    /**
     * Retrieves the latest captured screen frame Bitmap.
     * Returns null if capture is lost or unavailable.
     */
    fun acquireLatestFrame(): Bitmap? {
        val service = ScreenCaptureService.instance ?: return null
        if (!ScreenCaptureService.isCapturing.value) return null
        return service.captureLatestBitmap()
    }
}
