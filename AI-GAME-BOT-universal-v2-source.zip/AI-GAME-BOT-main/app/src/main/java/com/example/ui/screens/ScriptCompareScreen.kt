package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonGreen

const val PYTHON_SCRIPT_CODE = """# AI Game Bot - Python ADB Version
# Android फ़ोन का गेम खुद पहचानकर खेलता है।

import base64
import io
import json
import re
import subprocess
import time
import anthropic
from PIL import Image

MODEL = "claude-sonnet-5-5"
MAX_STEPS = 300
DELAY = 1.0
IMG_WIDTH = 720

client = anthropic.Anthropic()

SYSTEM = \"\"\"You are an AI that plays mobile games by looking at screenshots.
Each turn: identify the game and genre, decide the single best next action to
progress/complete the level, and reply with ONLY JSON:
{"game": "name", "genre": "racing/puzzle/runner/...", "thought": "short reasoning",
 "action": "tap" | "swipe" | "wait" | "back" | "done",
 "x": int, "y": int, "x2": int, "y2": int, "duration_ms": int}\"\"\"

def adb(*args, binary=False):
    out = subprocess.run(["adb", *args], capture_output=True, check=True).stdout
    return out if binary else out.decode().strip()

def screenshot():
    png = adb("exec-out", "screencap", "-p", binary=True)
    img = Image.open(io.BytesIO(png)).convert("RGB")
    real_w, real_h = img.size
    scale = real_w / IMG_WIDTH
    small = img.resize((IMG_WIDTH, int(real_h / scale)))
    buf = io.BytesIO()
    small.save(buf, format="JPEG", quality=80)
    return base64.b64encode(buf.getvalue()).decode(), scale

def ask_ai(img_b64, history):
    msg = client.messages.create(
        model=MODEL,
        max_tokens=400,
        system=SYSTEM,
        messages=[{"role": "user", "content": [
            {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": img_b64}},
            {"type": "text", "text": "Recent actions: " + " | ".join(history[-5:]) + "\\nWhat is the next action?"}
        ]}]
    )
    text = msg.content[0].text
    return json.loads(re.search(r"\{.*\}", text, re.S).group(0))

def act(a, scale):
    kind = a.get("action")
    s = lambda v: str(int(float(v) * scale))
    if kind == "tap":
        adb("shell", "input", "tap", s(a["x"]), s(a["y"]))
    elif kind == "swipe":
        adb("shell", "input", "swipe", s(a["x"]), s(a["y"]), s(a["x2"]), s(a["y2"]), str(a.get("duration_ms", 300)))
    elif kind == "back":
        adb("shell", "input", "keyevent", "KEYCODE_BACK")
"""

@Composable
fun ScriptCompareScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current

    fun copyText(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label कॉपी हो गया!", Toast.LENGTH_SHORT).show()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Python Script vs Android APK",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
            Text(
                "अब कंप्यूटर या ADB केबल की जरूरत नहीं! सीधे फ़ोन में सब कुछ।",
                color = CyberCyan,
                fontSize = 12.sp
            )
        }

        // Comparison Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // PC Mode Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Laptop, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Python + ADB", color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("• लैपटॉप/PC आवश्यक\n• USB Debugging & केबल\n• टर्मिनल से कमांड चलाना\n• स्क्रीन देखने के लिए PC पर निर्भर", color = Color(0xFF64748B), fontSize = 11.sp, lineHeight = 16.sp)
                    }
                }

                // APK Mode Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A263E))
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Native APK (यह ऐप)", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("• नो PC, नो USB केबल\n• सीधे फ़ोन में स्क्रीन कैप्चर\n• Accessibility सर्विस द्वारा ऑटो टैप\n• फ़्लोटिंग HUD ओवरले किसी भी गेम पर", color = Color(0xFFE2E8F0), fontSize = 11.sp, lineHeight = 16.sp)
                    }
                }
            }
        }

        // How it works inside APK
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = CyberCyan)
                        Spacer(Modifier.width(8.dp))
                        Text("APK में कैसे काम करता है?", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "1. **Accessibility Service**: Android OS का आधिकारिक फीचर, जो स्क्रीन पर बिना रूट (No Root) के स्वाइप और टैप करता है।\n" +
                        "2. **Gemini Vision AI Engine**: हर 1 सेकंड में गेम की स्क्रीन को प्रोसेस करके गेम व रणनीति पहचानता है।\n" +
                        "3. **Floating Overlay HUD**: किसी भी गेम (Subway Surfers, Candy Crush, आदि) को खोलें और ऊपर फ़्लोटिंग 'START' बटन दबाएं।",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Script Viewer & Copy
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1422))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Code, contentDescription = null, tint = ElectricPurple)
                            Spacer(Modifier.width(8.dp))
                            Text("Python ADB Script (game_bot.py)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        OutlinedButton(
                            onClick = { copyText("Python Game Bot Script", PYTHON_SCRIPT_CODE) },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Copy Script", color = CyberCyan, fontSize = 11.sp)
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF060911))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = PYTHON_SCRIPT_CODE,
                            color = Color(0xFF7DD3FC),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(24.dp))
        }
    }
}
