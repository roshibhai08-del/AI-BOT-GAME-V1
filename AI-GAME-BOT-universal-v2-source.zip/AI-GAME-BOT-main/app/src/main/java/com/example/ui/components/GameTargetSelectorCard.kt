package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.controller.GameBotController
import com.example.model.BotConfig
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonGreen

data class GamePreset(val name: String, val icon: String, val defaultGoal: String)

val POPULAR_GAMES = listOf(
    GamePreset("Auto Detect", "🤖", "गेम की स्क्रीन देखकर खुद पहचानो और सबसे अच्छा मूव करो"),
    GamePreset("Subway Surfers", "🏃", "बाधाओं (Trains/Barriers) से बचो और सिक्के/मैग्नेट संकलित करो"),
    GamePreset("Candy Crush", "🍬", "3 या अधिक रंगीन कैंडीज मिलाओ और जेली फोड़ो"),
    GamePreset("Temple Run", "🗿", "मोड़ पर स्वाइप करो, बाधाओं के नीचे झुको और ऊपर कूदो"),
    GamePreset("Hill Climb Racing", "🚗", "गैस और ब्रेक को संतुलित करो, गाड़ी पलटने मत दो"),
    GamePreset("Tile 2048", "🧩", "समान संख्याओं को जोड़ो और 2048 टाइल तक पहुंचो"),
    GamePreset("Ludo King", "👑", "पासा फेंको और गोटियों को सुरक्षित घर तक पहुंचाओ"),
    GamePreset("Chess", "♟️", "विपक्षी मोहरों को कैप्चर करो और चेकमेट की तैयारी करो")
)

@Composable
fun GameTargetSelectorCard(
    config: BotConfig,
    onUpdateConfig: ((BotConfig) -> BotConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    var isCustomGameInput by remember { mutableStateOf(false) }
    var customGameText by remember(config.targetGame) { mutableStateOf(config.targetGame) }
    var customGoalText by remember(config.customGoal) { mutableStateOf(config.customGoal) }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.SportsEsports,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "बोट को बताएं कौन सा गेम खेलना है",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }

            Spacer(Modifier.height(4.dp))
            Text(
                text = "यहाँ गेम और रणनीति सेट करें, ताकि AI बोट बिल्कुल सही तरीके से खेल सके:",
                color = Color(0xFF94A3B8),
                fontSize = 12.sp
            )

            Spacer(Modifier.height(12.dp))

            // Horizontal Scroll of Popular Games
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                POPULAR_GAMES.forEach { preset ->
                    val isSelected = config.targetGame == preset.name
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            isCustomGameInput = false
                            onUpdateConfig {
                                it.copy(
                                    targetGame = preset.name,
                                    customGoal = preset.defaultGoal
                                )
                            }
                        },
                        label = {
                            Text("${preset.icon} ${preset.name}", fontSize = 12.sp)
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberCyan,
                            selectedLabelColor = Color(0xFF00363D),
                            containerColor = Color(0xFF1B2335),
                            labelColor = Color(0xFFCBD5E1)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // Custom Game Button
                FilterChip(
                    selected = isCustomGameInput || (!POPULAR_GAMES.any { it.name == config.targetGame }),
                    onClick = {
                        isCustomGameInput = true
                    },
                    label = {
                        Text("✏️ अन्य गेम...", fontSize = 12.sp)
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ElectricPurple,
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF1B2335),
                        labelColor = Color(0xFFCBD5E1)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // If custom game or user wants to edit game name
            if (isCustomGameInput || !POPULAR_GAMES.any { it.name == config.targetGame }) {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = customGameText,
                    onValueChange = {
                        customGameText = it
                        onUpdateConfig { c -> c.copy(targetGame = it) }
                    },
                    label = { Text("गेम का नाम लिखें (Game Name)") },
                    placeholder = { Text("उदा. Ludo, BGMI, Fruit Ninja...") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = Color(0xFF28344D),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    singleLine = true
                )
            }

            Spacer(Modifier.height(12.dp))

            // Objective / Strategy Input
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Flag,
                    contentDescription = null,
                    tint = NeonGreen,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "बोट के लिए रणनीति / लक्ष्य (Strategy / Goal):",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
            }

            Spacer(Modifier.height(6.dp))

            OutlinedTextField(
                value = customGoalText,
                onValueChange = {
                    customGoalText = it
                    onUpdateConfig { c -> c.copy(customGoal = it) }
                },
                placeholder = { Text("उदा. सिर्फ लाल गेंदों को टैप करो / लेवल 5 पास करो...") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonGreen,
                    unfocusedBorderColor = Color(0xFF28344D),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                maxLines = 2
            )

            Spacer(Modifier.height(8.dp))

            // Active Target Pill
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F1420), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "🎯 वर्तमान बोट टारगेट: ${config.targetGame} • \"${config.customGoal}\"",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
