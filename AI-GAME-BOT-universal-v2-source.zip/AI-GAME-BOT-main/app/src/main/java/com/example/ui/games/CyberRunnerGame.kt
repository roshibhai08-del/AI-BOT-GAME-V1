package com.example.ui.games

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.controller.GameBotController
import com.example.controller.SimulatorGameDelegate
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.random.Random

data class RunnerObstacle(
    val id: Long = Random.nextLong(),
    val lane: Int, // 0, 1, 2
    var yPos: Float, // 0.0f (top) to 1.0f (bottom)
    val isCoin: Boolean = false
)

@Composable
fun CyberRunnerGame(
    controller: GameBotController,
    modifier: Modifier = Modifier
) {
    var playerLane by remember { mutableIntStateOf(1) } // 0: Left, 1: Center, 2: Right
    var isJumping by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) }
    var coinsCollected by remember { mutableIntStateOf(0) }
    var isGameOver by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }
    var gameSpeed by remember { mutableFloatStateOf(0.015f) }

    val obstacles = remember { mutableStateListOf<RunnerObstacle>() }
    var lastGestureIndicator by remember { mutableStateOf<String?>(null) }

    // Register with GameBotController as active simulator
    DisposableEffect(Unit) {
        val delegate = object : SimulatorGameDelegate {
            override fun captureFrame(): Bitmap {
                val bmp = Bitmap.createBitmap(720, 1280, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                // Draw background
                canvas.drawColor(0xFF0F172A.toInt())

                // Draw 3 lanes
                val laneWidth = 720f / 3f
                val dividerPaint = Paint().apply {
                    color = 0x3300E5FF.toInt()
                    strokeWidth = 4f
                }
                canvas.drawLine(laneWidth, 0f, laneWidth, 1280f, dividerPaint)
                canvas.drawLine(laneWidth * 2f, 0f, laneWidth * 2f, 1280f, dividerPaint)

                // Draw obstacles & coins
                val obsPaint = Paint().apply { color = 0xFFFF4444.toInt() }
                val coinPaint = Paint().apply { color = 0xFFFFD700.toInt() }

                for (obs in obstacles) {
                    val obsX = obs.lane * laneWidth + laneWidth * 0.15f
                    val obsY = obs.yPos * 1280f
                    if (obs.isCoin) {
                        canvas.drawCircle(obsX + laneWidth * 0.35f, obsY + 30f, 30f, coinPaint)
                    } else {
                        val rect = RectF(obsX, obsY, obsX + laneWidth * 0.7f, obsY + 120f)
                        canvas.drawRoundRect(rect, 20f, 20f, obsPaint)
                    }
                }

                // Draw player
                val playerPaint = Paint().apply { color = 0xFF00E5FF.toInt() }
                val playerX = playerLane * laneWidth + laneWidth * 0.2f
                val playerY = if (isJumping) 900f else 1050f
                canvas.drawRoundRect(
                    RectF(playerX, playerY, playerX + laneWidth * 0.6f, playerY + 140f),
                    30f, 30f, playerPaint
                )

                // Header text
                val textPaint = Paint().apply {
                    color = 0xFFFFFFFF.toInt()
                    textSize = 42f
                    isFakeBoldText = true
                }
                canvas.drawText("Cyber Runner | Score: $score | Coins: $coinsCollected", 40f, 80f, textPaint)

                return bmp
            }

            override fun onSimulatedTap(x: Float, y: Float) {
                lastGestureIndicator = "Tap @ (${x.toInt()}, ${y.toInt()})"
                // Tap upper area to jump
                if (y < 600f) {
                    isJumping = true
                }
            }

            override fun onSimulatedSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
                val dx = x2 - x1
                val dy = y2 - y1

                if (abs(dx) > abs(dy)) {
                    if (dx > 50 && playerLane < 2) {
                        playerLane++
                        lastGestureIndicator = "Swipe Right ➡ Lane $playerLane"
                    } else if (dx < -50 && playerLane > 0) {
                        playerLane--
                        lastGestureIndicator = "Swipe Left ⬅ Lane $playerLane"
                    }
                } else {
                    if (dy < -50) {
                        isJumping = true
                        lastGestureIndicator = "Swipe Up ⬆ Jump!"
                    }
                }
            }

            override fun getGameTitle(): String = "Cyber Runner"
            override fun getGameGenre(): String = "runner"
        }

        controller.activeSimulator = delegate
        onDispose {
            controller.activeSimulator = null
        }
    }

    // Reset Jump after delay
    LaunchedEffect(isJumping) {
        if (isJumping) {
            delay(500)
            isJumping = false
        }
    }

    // Clear gesture indicator
    LaunchedEffect(lastGestureIndicator) {
        if (lastGestureIndicator != null) {
            delay(1200)
            lastGestureIndicator = null
        }
    }

    // Game Loop
    LaunchedEffect(isGameOver, isPaused) {
        while (!isGameOver && !isPaused) {
            delay(32) // ~30 fps
            score += 1

            // Spawn obstacles
            if (Random.nextFloat() < 0.035f && obstacles.size < 5) {
                val freeLane = Random.nextInt(3)
                val isCoin = Random.nextFloat() < 0.4f
                obstacles.add(RunnerObstacle(lane = freeLane, yPos = -0.1f, isCoin = isCoin))
            }

            // Update obstacles
            val toRemove = mutableListOf<RunnerObstacle>()
            for (obs in obstacles) {
                obs.yPos += gameSpeed

                // Check collision with player around yPos 0.75 - 0.85
                if (obs.yPos in 0.70f..0.85f && obs.lane == playerLane) {
                    if (obs.isCoin) {
                        coinsCollected += 1
                        score += 50
                        toRemove.add(obs)
                    } else if (!isJumping) {
                        isGameOver = true
                    }
                }

                if (obs.yPos > 1.1f) {
                    toRemove.add(obs)
                }
            }
            obstacles.removeAll(toRemove)
        }
    }

    fun restartGame() {
        obstacles.clear()
        score = 0
        coinsCollected = 0
        playerLane = 1
        isGameOver = false
        isPaused = false
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
            .pointerInput(Unit) {
                var startX = 0f
                var startY = 0f
                detectDragGestures(
                    onDragStart = { offset ->
                        startX = offset.x
                        startY = offset.y
                    },
                    onDragEnd = {},
                    onDragCancel = {},
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val dx = change.position.x - startX
                        val dy = change.position.y - startY
                        if (abs(dx) > 60) {
                            if (dx > 0 && playerLane < 2) {
                                playerLane++
                                startX = change.position.x
                            } else if (dx < 0 && playerLane > 0) {
                                playerLane--
                                startX = change.position.x
                            }
                        } else if (dy < -60) {
                            isJumping = true
                            startY = change.position.y
                        }
                    }
                )
            }
    ) {
        val totalWidth = maxWidth
        val totalHeight = maxHeight
        val laneWidth = totalWidth / 3

        // Lanes visual gradient
        Row(modifier = Modifier.fillMaxSize()) {
            for (i in 0..2) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .background(
                            if (i % 2 == 0) Color(0xFF0F1524) else Color(0xFF131A2D)
                        )
                ) {
                    // Lane divider line
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.02f)
                            .fillMaxSize()
                            .align(Alignment.CenterEnd)
                            .background(Color(0x2200E5FF))
                    )
                }
            }
        }

        // Obstacles & Coins
        for (obs in obstacles) {
            val obsX = laneWidth * obs.lane + (laneWidth - 70.dp) / 2
            val obsY = totalHeight * obs.yPos

            if (obs.isCoin) {
                Box(
                    modifier = Modifier
                        .offset { IntOffset(obsX.roundToPx(), obsY.roundToPx()) }
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFFD700))
                        .shadow(8.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🪙", fontSize = 18.sp)
                }
            } else {
                Box(
                    modifier = Modifier
                        .offset { IntOffset(obsX.roundToPx(), obsY.roundToPx()) }
                        .size(width = 72.dp, height = 50.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.verticalGradient(listOf(Color(0xFFFF4444), Color(0xFFCC1111)))
                        )
                        .shadow(10.dp, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🚧", fontSize = 24.sp)
                }
            }
        }

        // Player Character
        val animatedPlayerLaneX by animateFloatAsState(
            targetValue = playerLane.toFloat(),
            animationSpec = tween(durationMillis = 180),
            label = "player_lane"
        )
        val playerX = laneWidth * animatedPlayerLaneX + (laneWidth - 64.dp) / 2
        val playerY = if (isJumping) totalHeight * 0.65f else totalHeight * 0.78f

        Box(
            modifier = Modifier
                .offset { IntOffset(playerX.roundToPx(), playerY.roundToPx()) }
                .size(64.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    Brush.radialGradient(listOf(CyberCyan, Color(0xFF007A8A)))
                )
                .shadow(16.dp, RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(if (isJumping) "🚀" else "🤖", fontSize = 32.sp)
        }

        // Top HUD Overlay
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xDD131B2A)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⚡ $score", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.width(16.dp))
                    Text("🪙 $coinsCollected", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { restartGame() },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xDD1E293B))
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = Color.White)
                }
            }
        }

        // Live AI Action Banner if active
        lastGestureIndicator?.let { indicator ->
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 70.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xEE00E5FF))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    "AI Action: $indicator",
                    color = Color(0xFF00363D),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        // Game Over Dialog
        if (isGameOver) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xCC000000)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131926)),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.padding(32.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("💥 CRASH!", color = Color(0xFFFF5252), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Final Score: $score", color = Color.White, fontSize = 18.sp)
                        Text("Coins: $coinsCollected", color = Color(0xFFFFD700), fontSize = 16.sp)
                        Spacer(Modifier.height(20.dp))

                        Button(
                            onClick = { restartGame() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
                        ) {
                            Text("Play Again", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
