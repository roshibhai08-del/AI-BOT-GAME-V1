package com.example.engine

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import com.example.service.GameBotAccessibilityService

data class ForegroundAppInfo(
    val packageName: String,
    val appLabel: String
)

class ForegroundAppDetector(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    /**
     * Determines the current foreground application package name and its human-readable label.
     */
    fun detectForegroundApp(simulatedPackage: String? = null): ForegroundAppInfo? {
        // Priority 0: Active in-app simulator override
        if (!simulatedPackage.isNullOrBlank()) {
            return ForegroundAppInfo(
                packageName = simulatedPackage,
                appLabel = getLabelFromPackage(simulatedPackage) ?: formatPackageToTitle(simulatedPackage)
            )
        }

        // Priority 1: Accessibility Service active window package
        val accessService = GameBotAccessibilityService.instance
        if (accessService != null) {
            val pkg = accessService.getTopPackageName()
            if (!pkg.isNullOrBlank() && pkg != context.packageName) {
                val label = getLabelFromPackage(pkg) ?: formatPackageToTitle(pkg)
                return ForegroundAppInfo(pkg, label)
            }
        }

        // Priority 2: ActivityManager running process check
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val processes = am?.runningAppProcesses
            if (processes != null) {
                for (proc in processes) {
                    if (proc.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND &&
                        proc.processName != context.packageName
                    ) {
                        val pkg = proc.processName
                        val label = getLabelFromPackage(pkg) ?: formatPackageToTitle(pkg)
                        return ForegroundAppInfo(pkg, label)
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore system permission restriction
        }

        return null
    }

    fun getLabelFromPackage(packageName: String): String? {
        return try {
            val appInfo = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            null
        }
    }

    private fun formatPackageToTitle(pkg: String): String {
        val parts = pkg.split(".")
        val last = parts.lastOrNull() ?: pkg
        return last.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
}
