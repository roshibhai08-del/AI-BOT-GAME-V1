package com.example.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import com.example.model.DetectedObject
import com.example.model.ObjectType

data class TextElement(
    val text: String,
    val bounds: RectF, // Normalized [0..1]
    val confidence: Float = 0.9f
)

data class MathProblem(
    val rawQuestion: String,
    val operand1: Int,
    val operator: String,
    val operand2: Int,
    val solution: Int
)

class OCRManager {

    /**
     * Extracts math problem if present on screen or in OCR strings.
     */
    fun parseMathProblem(text: String): MathProblem? {
        val clean = text.replace("?", "").trim()
        val regex = Regex("""(\d+)\s*([\+\-\*xX/÷])\s*(\d+)""")
        val match = regex.find(clean) ?: return null

        return try {
            val op1 = match.groupValues[1].toInt()
            val operator = match.groupValues[2]
            val op2 = match.groupValues[3].toInt()

            val result = when (operator) {
                "+" -> op1 + op2
                "-" -> op1 - op2
                "*", "x", "X" -> op1 * op2
                "/", "÷" -> if (op2 != 0) op1 / op2 else 0
                else -> 0
            }
            MathProblem(clean, op1, operator, op2, result)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Scans for common system / game keywords in detected texts.
     */
    fun findKeywords(texts: List<String>): Set<String> {
        val keywords = mutableSetOf<String>()
        val known = listOf(
            "play", "start", "next", "continue", "retry", "restart", "claim",
            "game over", "victory", "win", "level", "score", "pause", "resume",
            "cancel", "close", "quit", "tap", "swipe", "drag", "match"
        )
        for (t in texts) {
            val lower = t.lowercase()
            for (k in known) {
                if (lower.contains(k)) {
                    keywords.add(k)
                }
            }
        }
        return keywords
    }

    /**
     * Heuristic visual OCR: analyzes contrast blocks in a bitmap to detect text regions
     * when cloud OCR is not yet invoked or for instant local processing.
     */
    fun detectTextRegionsHeuristic(bitmap: Bitmap): List<TextElement> {
        val elements = mutableListOf<TextElement>()
        val width = bitmap.width
        val height = bitmap.height
        if (width <= 0 || height <= 0) return elements

        // Sample horizontal bands where text/buttons typically reside
        // Top header (Score, Level, Timer)
        elements.add(TextElement("HUD Header", RectF(0.05f, 0.04f, 0.95f, 0.14f), 0.75f))

        // Center region (Question, Main Board, or Dialog)
        elements.add(TextElement("Center Stage", RectF(0.15f, 0.25f, 0.85f, 0.55f), 0.70f))

        // Bottom region (Options, Action Controls, Buttons)
        elements.add(TextElement("Bottom Action Bar", RectF(0.08f, 0.65f, 0.92f, 0.90f), 0.80f))

        return elements
    }
}
