package com.example.ui.games

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.controller.GameBotController
import com.example.controller.SimulatorGameDelegate
import com.example.ui.theme.CyberCyan
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.random.Random

@Composable
fun TileGridMatchGame(
    controller: GameBotController,
    modifier: Modifier = Modifier
) {
    var board by remember {
        mutableStateOf(Array(4) { IntArray(4) })
    }
    var score by remember { mutableIntStateOf(0) }
    var bestTile by remember { mutableIntStateOf(2) }
    var lastGestureIndicator by remember { mutableStateOf<String?>(null) }

    fun addRandomTile(currentBoard: Array<IntArray>): Boolean {
        val emptyCells = mutableListOf<Pair<Int, Int>>()
        for (r in 0..3) {
            for (c in 0..3) {
                if (currentBoard[r][c] == 0) emptyCells.add(Pair(r, c))
            }
        }
        if (emptyCells.isEmpty()) return false
        val (r, c) = emptyCells[Random.nextInt(emptyCells.size)]
        currentBoard[r][c] = if (Random.nextFloat() < 0.9f) 2 else 4
        return true
    }

    fun initBoard() {
        val newBoard = Array(4) { IntArray(4) }
        addRandomTile(newBoard)
        addRandomTile(newBoard)
        board = newBoard
        score = 0
        bestTile = 2
    }

    LaunchedEffect(Unit) {
        if (board[0][0] == 0 && board[1][1] == 0 && board[2][2] == 0) {
            initBoard()
        }
    }

    fun slideRow(row: IntArray): Pair<IntArray, Int> {
        val filtered = row.filter { it != 0 }.toMutableList()
        var gainedScore = 0
        var i = 0
        while (i < filtered.size - 1) {
            if (filtered[i] == filtered[i + 1]) {
                filtered[i] *= 2
                gainedScore += filtered[i]
                filtered.removeAt(i + 1)
            }
            i++
        }
        while (filtered.size < 4) {
            filtered.add(0)
        }
        return Pair(filtered.toIntArray(), gainedScore)
    }

    fun moveLeft() {
        var changed = false
        var gainedScore = 0
        val newBoard = Array(4) { IntArray(4) }
        for (r in 0..3) {
            val (newRow, pts) = slideRow(board[r])
            newBoard[r] = newRow
            gainedScore += pts
            if (!board[r].contentEquals(newRow)) changed = true
        }
        if (changed) {
            addRandomTile(newBoard)
            board = newBoard
            score += gainedScore
            bestTile = maxOf(bestTile, newBoard.flatMap { it.asIterable() }.maxOrNull() ?: 2)
            lastGestureIndicator = "Swipe Left ⬅"
        }
    }

    fun moveRight() {
        var changed = false
        var gainedScore = 0
        val newBoard = Array(4) { IntArray(4) }
        for (r in 0..3) {
            val reversed = board[r].reversedArray()
            val (newRow, pts) = slideRow(reversed)
            val result = newRow.reversedArray()
            newBoard[r] = result
            gainedScore += pts
            if (!board[r].contentEquals(result)) changed = true
        }
        if (changed) {
            addRandomTile(newBoard)
            board = newBoard
            score += gainedScore
            bestTile = maxOf(bestTile, newBoard.flatMap { it.asIterable() }.maxOrNull() ?: 2)
            lastGestureIndicator = "Swipe Right ➡"
        }
    }

    fun moveUp() {
        var changed = false
        var gainedScore = 0
        val newBoard = Array(4) { IntArray(4) }
        for (c in 0..3) {
            val col = IntArray(4) { r -> board[r][c] }
            val (newCol, pts) = slideRow(col)
            gainedScore += pts
            for (r in 0..3) {
                newBoard[r][c] = newCol[r]
                if (board[r][c] != newCol[r]) changed = true
            }
        }
        if (changed) {
            addRandomTile(newBoard)
            board = newBoard
            score += gainedScore
            bestTile = maxOf(bestTile, newBoard.flatMap { it.asIterable() }.maxOrNull() ?: 2)
            lastGestureIndicator = "Swipe Up ⬆"
        }
    }

    fun moveDown() {
        var changed = false
        var gainedScore = 0
        val newBoard = Array(4) { IntArray(4) }
        for (c in 0..3) {
            val col = IntArray(4) { r -> board[3 - r][c] }
            val (newCol, pts) = slideRow(col)
            gainedScore += pts
            for (r in 0..3) {
                newBoard[3 - r][c] = newCol[r]
                if (board[3 - r][c] != newCol[r]) changed = true
            }
        }
        if (changed) {
            addRandomTile(newBoard)
            board = newBoard
            score += gainedScore
            bestTile = maxOf(bestTile, newBoard.flatMap { it.asIterable() }.maxOrNull() ?: 2)
            lastGestureIndicator = "Swipe Down ⬇"
        }
    }

    // Register with GameBotController
    DisposableEffect(board) {
        val delegate = object : SimulatorGameDelegate {
            override fun captureFrame(): Bitmap {
                val bmp = Bitmap.createBitmap(720, 1280, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                canvas.drawColor(0xFF0F172A.toInt())

                val headerPaint = Paint().apply {
                    color = 0xFFFFFFFF.toInt()
                    textSize = 40f
                    isFakeBoldText = true
                }
                canvas.drawText("Color Tile 2048 | Score: $score", 50f, 150f, headerPaint)

                val gridStartX = 60f
                val gridStartY = 280f
                val tileSize = 140f
                val gap = 10f

                for (r in 0..3) {
                    for (c in 0..3) {
                        val v = board[r][c]
                        val x = gridStartX + c * (tileSize + gap)
                        val y = gridStartY + r * (tileSize + gap)
                        val tilePaint = Paint().apply {
                            color = when (v) {
                                2 -> 0xFF334155.toInt()
                                4 -> 0xFF475569.toInt()
                                8 -> 0xFFE056FD.toInt()
                                16 -> 0xFF686DE0.toInt()
                                32 -> 0xFF00E5FF.toInt()
                                64 -> 0xFF00E676.toInt()
                                128 -> 0xFFFFBE76.toInt()
                                256 -> 0xFFFF7979.toInt()
                                else -> 0xFF1E293B.toInt()
                            }
                        }
                        canvas.drawRoundRect(RectF(x, y, x + tileSize, y + tileSize), 16f, 16f, tilePaint)
                        if (v > 0) {
                            val textP = Paint().apply {
                                color = 0xFFFFFFFF.toInt()
                                textSize = 44f
                                textAlign = Paint.Align.CENTER
                                isFakeBoldText = true
                            }
                            canvas.drawText(v.toString(), x + tileSize / 2, y + tileSize / 2 + 15, textP)
                        }
                    }
                }
                return bmp
            }

            override fun onSimulatedTap(x: Float, y: Float) {
                // Tap on right half -> move right, left half -> move left
                if (x > 360f) moveRight() else moveLeft()
            }

            override fun onSimulatedSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
                val dx = x2 - x1
                val dy = y2 - y1
                if (abs(dx) > abs(dy)) {
                    if (dx > 40) moveRight() else if (dx < -40) moveLeft()
                } else {
                    if (dy > 40) moveDown() else if (dy < -40) moveUp()
                }
            }

            override fun getGameTitle(): String = "Color Tile Grid"
            override fun getGameGenre(): String = "puzzle"
        }

        controller.activeSimulator = delegate
        onDispose {
            controller.activeSimulator = null
        }
    }

    LaunchedEffect(lastGestureIndicator) {
        if (lastGestureIndicator != null) {
            delay(1200)
            lastGestureIndicator = null
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top score bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2335)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text("SCORE", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("$score", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.size(10.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2335)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text("MAX TILE", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("$bestTile", color = CyberCyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            IconButton(
                onClick = { initBoard() },
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1B2335))
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = Color.White)
            }
        }

        Spacer(Modifier.height(16.dp))

        lastGestureIndicator?.let { indicator ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xEE00E5FF))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    "AI Action: $indicator",
                    color = Color(0xFF00363D),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
            Spacer(Modifier.height(8.dp))
        }

        // 4x4 Grid Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF131926))
                .padding(8.dp)
                .pointerInput(Unit) {
                    var startX = 0f
                    var startY = 0f
                    detectDragGestures(
                        onDragStart = { offset ->
                            startX = offset.x
                            startY = offset.y
                        },
                        onDragEnd = {},
                        onDragCancel = {},
                        onDrag = { change, _ ->
                            change.consume()
                            val dx = change.position.x - startX
                            val dy = change.position.y - startY
                            if (abs(dx) > 60 || abs(dy) > 60) {
                                if (abs(dx) > abs(dy)) {
                                    if (dx > 0) moveRight() else moveLeft()
                                } else {
                                    if (dy > 0) moveDown() else moveUp()
                                }
                                startX = change.position.x
                                startY = change.position.y
                            }
                        }
                    )
                }
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (r in 0..3) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (c in 0..3) {
                            val v = board[r][c]
                            val tileColor = when (v) {
                                0 -> Color(0xFF1E2638)
                                2 -> Color(0xFF2C394F)
                                4 -> Color(0xFF384B66)
                                8 -> Color(0xFF6C5CE7)
                                16 -> Color(0xFF00B894)
                                32 -> Color(0xFF0984E3)
                                64 -> Color(0xFFE84393)
                                128 -> Color(0xFFF39C12)
                                256 -> Color(0xFFE74C3C)
                                512 -> Color(0xFFD35400)
                                1024 -> Color(0xFF8E44AD)
                                else -> Color(0xFFF1C40F)
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(tileColor),
                                contentAlignment = Alignment.Center
                            ) {
                                if (v > 0) {
                                    Text(
                                        text = "$v",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = if (v >= 1000) 18.sp else 22.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "स्वाइप करें या AI बोट को अपने आप खेलने दें",
            color = Color(0xFF64748B),
            fontSize = 13.sp
        )
    }
}
