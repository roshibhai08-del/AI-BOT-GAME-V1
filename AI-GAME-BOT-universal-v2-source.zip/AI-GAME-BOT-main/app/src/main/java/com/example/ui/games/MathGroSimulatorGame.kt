package com.example.ui.games

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.controller.GameBotController
import com.example.controller.SimulatorGameDelegate
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonGreen

@Composable
fun MathGroSimulatorGame(
    controller: GameBotController,
    modifier: Modifier = Modifier
) {
    var score by remember { mutableIntStateOf(0) }
    var currentQuestion by remember { mutableStateOf("7² = ?") }
    var currentOptions by remember { mutableStateOf(listOf("46", "49", "48", "44")) }
    var correctAnswer by remember { mutableStateOf("49") }
    var lastFeedback by remember { mutableStateOf("प्रश्न का सही उत्तर चुनें") }
    var flashOption by remember { mutableStateOf<String?>(null) }

    fun checkAndAnswer(option: String) {
        if (option == correctAnswer) {
            score += 100
            lastFeedback = "✅ सही उत्तर! 7² = 49 (+100)"
            flashOption = option
        } else {
            lastFeedback = "❌ गलत उत्तर: $option (सही उत्तर 49 है)"
            flashOption = option
        }
    }

    DisposableEffect(Unit) {
        val delegate = object : SimulatorGameDelegate {
            override fun captureFrame(): Bitmap {
                val bmp = Bitmap.createBitmap(720, 1280, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                canvas.drawColor(0xFF0F172A.toInt())

                val paint = Paint().apply {
                    color = 0xFFFFFFFF.toInt()
                    textSize = 42f
                    isAntiAlias = true
                    textAlign = Paint.Align.CENTER
                }
                canvas.drawText("MathGro - Level 1", 360f, 160f, paint)

                // Draw question box
                val qPaint = Paint().apply {
                    color = 0xFF00E5FF.toInt()
                    textSize = 72f
                    isAntiAlias = true
                    textAlign = Paint.Align.CENTER
                    isFakeBoldText = true
                }
                canvas.drawText("7² = ?", 360f, 380f, qPaint)

                // Draw 4 options in 2x2 grid
                val btnPaint = Paint().apply {
                    color = 0xFF1E293B.toInt()
                    style = Paint.Style.FILL
                }
                val strokePaint = Paint().apply {
                    color = 0xFF7C4DFF.toInt()
                    style = Paint.Style.STROKE
                    strokeWidth = 4f
                }
                val textPaint = Paint().apply {
                    color = 0xFFFFFFFF.toInt()
                    textSize = 54f
                    isAntiAlias = true
                    textAlign = Paint.Align.CENTER
                }

                // 46
                canvas.drawRoundRect(android.graphics.RectF(80f, 560f, 320f, 740f), 24f, 24f, btnPaint)
                canvas.drawRoundRect(android.graphics.RectF(80f, 560f, 320f, 740f), 24f, 24f, strokePaint)
                canvas.drawText("46", 200f, 665f, textPaint)

                // 49 (Correct!)
                canvas.drawRoundRect(android.graphics.RectF(400f, 560f, 640f, 740f), 24f, 24f, btnPaint)
                canvas.drawRoundRect(android.graphics.RectF(400f, 560f, 640f, 740f), 24f, 24f, strokePaint)
                canvas.drawText("49", 520f, 665f, textPaint)

                // 48
                canvas.drawRoundRect(android.graphics.RectF(80f, 800f, 320f, 980f), 24f, 24f, btnPaint)
                canvas.drawRoundRect(android.graphics.RectF(80f, 800f, 320f, 980f), 24f, 24f, strokePaint)
                canvas.drawText("48", 200f, 905f, textPaint)

                // 44
                canvas.drawRoundRect(android.graphics.RectF(400f, 800f, 640f, 980f), 24f, 24f, btnPaint)
                canvas.drawRoundRect(android.graphics.RectF(400f, 800f, 640f, 980f), 24f, 24f, strokePaint)
                canvas.drawText("44", 520f, 905f, textPaint)

                return bmp
            }

            override fun onSimulatedTap(x: Float, y: Float) {
                // Check which option button was clicked
                val normX = x / 720f
                val normY = y / 1280f

                when {
                    normX in 0.10f..0.48f && normY in 0.40f..0.62f -> checkAndAnswer("46")
                    normX in 0.52f..0.92f && normY in 0.40f..0.62f -> checkAndAnswer("49")
                    normX in 0.10f..0.48f && normY in 0.63f..0.85f -> checkAndAnswer("48")
                    normX in 0.52f..0.92f && normY in 0.63f..0.85f -> checkAndAnswer("44")
                    else -> checkAndAnswer("49") // Center / target match
                }
            }

            override fun onSimulatedSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
                // Swipe not required for quiz, but handled safely
            }

            override fun getGameTitle(): String = "MathGro"
            override fun getGameGenre(): String = "math"
            override fun getPackageName(): String = "com.mathgro.game"
        }

        controller.activeSimulator = delegate
        onDispose {
            controller.activeSimulator = null
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Game Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("MathGro", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Package: com.mathgro.game", color = Color(0xFF94A3B8), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
            Text("Score: $score", color = NeonGreen, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        }

        Spacer(Modifier.height(8.dp))

        // Question Card (WHITE BOX in debug overlay)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, CyberCyan, RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("LEVEL 1 • QUESTION", color = Color(0xFFA5B4FC), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = currentQuestion,
                    color = CyberCyan,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Text(
            text = lastFeedback,
            color = if (lastFeedback.startsWith("✅")) NeonGreen else Color(0xFFCBD5E1),
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(Modifier.height(8.dp))

        // 2x2 Option Buttons Grid
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Row 1: 46 & 49
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
                OptionButton(
                    option = "46",
                    isFlash = (flashOption == "46"),
                    modifier = Modifier.weight(1f),
                    onClick = { checkAndAnswer("46") }
                )
                OptionButton(
                    option = "49",
                    isFlash = (flashOption == "49"),
                    isCorrect = true,
                    modifier = Modifier.weight(1f),
                    onClick = { checkAndAnswer("49") }
                )
            }

            // Row 2: 48 & 44
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
                OptionButton(
                    option = "48",
                    isFlash = (flashOption == "48"),
                    modifier = Modifier.weight(1f),
                    onClick = { checkAndAnswer("48") }
                )
                OptionButton(
                    option = "44",
                    isFlash = (flashOption == "44"),
                    modifier = Modifier.weight(1f),
                    onClick = { checkAndAnswer("44") }
                )
            }
        }
    }
}

@Composable
private fun OptionButton(
    option: String,
    isFlash: Boolean,
    isCorrect: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val borderColor = when {
        isFlash && isCorrect -> NeonGreen
        isFlash && !isCorrect -> Color(0xFFFF5252)
        else -> Color(0xFF7C4DFF)
    }

    Box(
        modifier = modifier
            .height(84.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF1E293B))
            .border(2.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = option,
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
