package com.example.ui.games

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.controller.GameBotController
import com.example.controller.SimulatorGameDelegate
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.random.Random

data class BlitzTarget(
    val id: Long = Random.nextLong(),
    val xRatio: Float, // 0.15f to 0.85f
    val yRatio: Float, // 0.15f to 0.85f
    val points: Int = 10,
    val color: Long = 0xFF00E5FF
)

@Composable
fun TapBlitzGame(
    controller: GameBotController,
    modifier: Modifier = Modifier
) {
    var score by remember { mutableIntStateOf(0) }
    var targetsHit by remember { mutableIntStateOf(0) }
    val activeTargets = remember { mutableStateListOf<BlitzTarget>() }
    var lastGestureIndicator by remember { mutableStateOf<String?>(null) }

    fun spawnTarget() {
        if (activeTargets.size < 4) {
            val colors = listOf(0xFF00E5FF, 0xFF00E676, 0xFFFFB300, 0xFFE056FD)
            activeTargets.add(
                BlitzTarget(
                    xRatio = 0.15f + Random.nextFloat() * 0.7f,
                    yRatio = 0.2f + Random.nextFloat() * 0.6f,
                    color = colors[Random.nextInt(colors.size)]
                )
            )
        }
    }

    LaunchedEffect(Unit) {
        spawnTarget()
        spawnTarget()
    }

    // Auto spawn targets
    LaunchedEffect(Unit) {
        while (true) {
            delay(1200)
            if (activeTargets.size < 4) {
                spawnTarget()
            }
        }
    }

    fun onHit(target: BlitzTarget) {
        activeTargets.remove(target)
        score += target.points
        targetsHit += 1
        spawnTarget()
    }

    DisposableEffect(activeTargets.toList()) {
        val delegate = object : SimulatorGameDelegate {
            override fun captureFrame(): Bitmap {
                val bmp = Bitmap.createBitmap(720, 1280, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                canvas.drawColor(0xFF0B0F19.toInt())

                val headerPaint = Paint().apply {
                    color = 0xFFFFFFFF.toInt()
                    textSize = 42f
                    isFakeBoldText = true
                }
                canvas.drawText("Tap Blitz | Score: $score | Hits: $targetsHit", 50f, 100f, headerPaint)

                for (target in activeTargets) {
                    val p = Paint().apply { color = target.color.toInt() }
                    val tx = target.xRatio * 720f
                    val ty = target.yRatio * 1280f
                    canvas.drawCircle(tx, ty, 50f, p)
                }
                return bmp
            }

            override fun onSimulatedTap(x: Float, y: Float) {
                // Check if tap hit any target
                lastGestureIndicator = "Tap @ (${x.toInt()}, ${y.toInt()})"
                val xRatio = x / 720f
                val yRatio = y / 1280f

                val hit = activeTargets.firstOrNull { t ->
                    val dx = (t.xRatio - xRatio) * 720f
                    val dy = (t.yRatio - yRatio) * 1280f
                    hypot(dx, dy) < 80f
                }

                if (hit != null) {
                    onHit(hit)
                }
            }

            override fun onSimulatedSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
                // Tap at end of swipe
                onSimulatedTap(x2, y2)
            }

            override fun getGameTitle(): String = "Tap Blitz"
            override fun getGameGenre(): String = "reaction"
        }

        controller.activeSimulator = delegate
        onDispose {
            controller.activeSimulator = null
        }
    }

    LaunchedEffect(lastGestureIndicator) {
        if (lastGestureIndicator != null) {
            delay(1200)
            lastGestureIndicator = null
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
    ) {
        val w = maxWidth
        val h = maxHeight

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2A)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🎯 HITS: $targetsHit", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.size(16.dp))
                        Text("⚡ SCORE: $score", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }

                IconButton(
                    onClick = {
                        activeTargets.clear()
                        score = 0
                        targetsHit = 0
                        spawnTarget()
                        spawnTarget()
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1B2335))
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = Color.White)
                }
            }

            lastGestureIndicator?.let { indicator ->
                Spacer(Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xEE00E5FF))
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Text(
                        "AI Action: $indicator",
                        color = Color(0xFF00363D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Active Target Circles
        for (target in activeTargets) {
            val targetX = w * target.xRatio - 36.dp
            val targetY = h * target.yRatio - 36.dp

            Box(
                modifier = Modifier
                    .offset { IntOffset(targetX.roundToPx(), targetY.roundToPx()) }
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Color(target.color))
                    .clickable { onHit(target) },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0x99FFFFFF)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🎯", fontSize = 20.sp)
                }
            }
        }
    }
}
