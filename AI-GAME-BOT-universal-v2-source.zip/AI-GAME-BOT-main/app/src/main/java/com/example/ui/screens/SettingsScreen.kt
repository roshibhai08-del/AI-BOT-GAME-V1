package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.controller.GameBotController
import com.example.model.ApiProvider
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonGreen
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    controller: GameBotController,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val config by controller.botConfig.collectAsState()
    var showApiKey by remember { mutableStateOf(false) }
    var apiKeyInput by remember(config.customApiKey) { mutableStateOf(config.customApiKey) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Bot कॉन्फ़िगरेशन व सेटिंग्स",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
            Text(
                "AI स्पीड, मॉडल व सुरक्षा नियम कस्टमाइज़ करें",
                color = CyberCyan,
                fontSize = 12.sp
            )
        }

        // AI Provider Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Key, contentDescription = null, tint = CyberCyan)
                        Spacer(Modifier.width(8.dp))
                        Text("AI Vision Provider", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    Spacer(Modifier.height(12.dp))

                    ApiProvider.values().forEach { provider ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = provider.displayName,
                                color = if (config.apiProvider == provider) CyberCyan else Color(0xFFCBD5E1),
                                fontSize = 13.sp,
                                fontWeight = if (config.apiProvider == provider) FontWeight.Bold else FontWeight.Normal
                            )

                            Button(
                                onClick = { controller.updateConfig { it.copy(apiProvider = provider) } },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (config.apiProvider == provider) CyberCyan else Color(0xFF1E283D)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (config.apiProvider == provider) "Selected" else "Select",
                                    color = if (config.apiProvider == provider) Color(0xFF00363D) else Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Custom API Key Input
                    if (config.apiProvider != ApiProvider.SMART_SIMULATOR) {
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = apiKeyInput,
                            onValueChange = {
                                apiKeyInput = it
                                controller.updateConfig { c -> c.copy(customApiKey = it) }
                            },
                            label = { Text("Custom API Key (वैकल्पिक / Optional)") },
                            visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { showApiKey = !showApiKey }) {
                                    Icon(
                                        if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = null,
                                        tint = Color(0xFF94A3B8)
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = Color(0xFF28344D),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true
                        )
                    }
                }
            }
        }

        // Timing & Speed Controls
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = NeonGreen)
                        Spacer(Modifier.width(8.dp))
                        Text("बोट स्पीड व स्टेप लिमिट", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    Spacer(Modifier.height(14.dp))

                    // Delay Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("एक्शन के बीच इंतज़ार (Delay)", color = Color(0xFFCBD5E1), fontSize = 13.sp)
                        Text(String.format("%.1f सेकंड", config.delaySeconds), color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(
                        value = config.delaySeconds,
                        onValueChange = { controller.updateConfig { c -> c.copy(delaySeconds = it) } },
                        valueRange = 0.3f..3.0f,
                        steps = 8,
                        colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                    )

                    Spacer(Modifier.height(10.dp))

                    // Max Steps Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("अधिकतम स्टेप्स (MAX_STEPS)", color = Color(0xFFCBD5E1), fontSize = 13.sp)
                        Text("${config.maxSteps} steps", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(
                        value = config.maxSteps.toFloat(),
                        onValueChange = { controller.updateConfig { c -> c.copy(maxSteps = it.roundToInt()) } },
                        valueRange = 50f..600f,
                        steps = 10,
                        colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
                    )
                }
            }
        }

        // Safety & Feedback
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFFFB300))
                        Spacer(Modifier.width(8.dp))
                        Text("सुरक्षा व प्रतिक्रिया (Safety Shield)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    Spacer(Modifier.height(14.dp))

                    // Purchase Protection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("असली पैसे की खरीद से सुरक्षा", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("गेम में इन-ऐप परचेज (INR/$) बटन पर टैप करने से रोकता है", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        }
                        Switch(
                            checked = config.safetyPurchaseProtection,
                            onCheckedChange = { controller.updateConfig { c -> c.copy(safetyPurchaseProtection = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = NeonGreen, checkedTrackColor = Color(0xFF004D25))
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    // Vibration
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("वाइब्रेशन फीडबैक (Haptic)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("हर टैप या स्वाइप पर हल्का कम्पन", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        }
                        Switch(
                            checked = config.vibrationFeedback,
                            onCheckedChange = { controller.updateConfig { c -> c.copy(vibrationFeedback = it) } },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = Color(0xFF004A54))
                        )
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(24.dp))
        }
    }
}
