package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.controller.GameBotController
import com.example.model.CalibrationProfile
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonGreen

@Composable
fun ScreenCalibrationDialog(
    controller: GameBotController,
    currentProfile: CalibrationProfile,
    onDismiss: () -> Unit
) {
    var offsetX by remember { mutableFloatStateOf(currentProfile.offsetX) }
    var offsetY by remember { mutableFloatStateOf(currentProfile.offsetY) }
    var scaleX by remember { mutableFloatStateOf(currentProfile.scaleX) }
    var scaleY by remember { mutableFloatStateOf(currentProfile.scaleY) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tune, contentDescription = null, tint = CyberCyan)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "स्क्रीन टच कैलिब्रेशन",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Text(
                        "${controller.coordinateMapper.physicalWidth}x${controller.coordinateMapper.physicalHeight}",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    "स्क्रीनशॉट और वास्तविक डिस्प्ले के टच पॉइंट्स को सटीक रूप से संरेखित (align) करें:",
                    color = Color(0xFFCBD5E1),
                    fontSize = 12.sp
                )

                // Offset X Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("X Offset (क्षैतिज विस्थापन):", color = Color.White, fontSize = 12.sp)
                        Text("${offsetX.toInt()} px", color = CyberCyan, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = offsetX,
                        onValueChange = {
                            offsetX = it
                            controller.updateCalibration(offsetX, offsetY, scaleX, scaleY)
                        },
                        valueRange = -100f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = CyberCyan,
                            activeTrackColor = CyberCyan
                        )
                    )
                }

                // Offset Y Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Y Offset (लंबवत विस्थापन):", color = Color.White, fontSize = 12.sp)
                        Text("${offsetY.toInt()} px", color = NeonGreen, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = offsetY,
                        onValueChange = {
                            offsetY = it
                            controller.updateCalibration(offsetX, offsetY, scaleX, scaleY)
                        },
                        valueRange = -150f..150f,
                        colors = SliderDefaults.colors(
                            thumbColor = NeonGreen,
                            activeTrackColor = NeonGreen
                        )
                    )
                }

                // Test Crosshair Preview Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F1420), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "🎯 कैलिब्रेटेड टेस्ट पॉइंट: (${(controller.coordinateMapper.physicalWidth / 2 + offsetX).toInt()}, ${(controller.coordinateMapper.physicalHeight / 2 + offsetY).toInt()})",
                        color = Color(0xFFFFD600),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            controller.resetCalibration()
                            offsetX = 0f
                            offsetY = 0f
                            scaleX = 1.0f
                            scaleY = 1.0f
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, Modifier.width(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("रीसेट", fontSize = 12.sp)
                    }

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("पूर्ण (Done)", color = Color(0xFF00363D), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
