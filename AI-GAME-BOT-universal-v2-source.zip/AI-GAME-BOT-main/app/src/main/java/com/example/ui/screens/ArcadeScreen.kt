package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.controller.GameBotController
import com.example.model.SimulatorGameType
import com.example.ui.games.CyberRunnerGame
import com.example.ui.games.TapBlitzGame
import com.example.ui.games.TileGridMatchGame
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonGreen

@Composable
fun ArcadeScreen(
    controller: GameBotController,
    modifier: Modifier = Modifier
) {
    var selectedGame by remember { mutableStateOf(SimulatorGameType.RUNNER) }
    val botState by controller.botState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(12.dp)
    ) {
        // Game selector chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SimulatorGameType.values().forEach { gameType ->
                FilterChip(
                    selected = selectedGame == gameType,
                    onClick = { selectedGame = gameType },
                    label = {
                        Text("${gameType.icon} ${gameType.title}", fontSize = 12.sp)
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyberCyan,
                        selectedLabelColor = Color(0xFF00363D),
                        containerColor = Color(0xFF131926),
                        labelColor = Color(0xFF94A3B8)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        // AI Bot Quick Control Bar over Game
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131926))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.SmartToy,
                        contentDescription = null,
                        tint = if (botState.isBotRunning) NeonGreen else CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (botState.isBotRunning) "AI Bot Playing (चल रहा है)" else "AI Bot Autoplay",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = if (botState.isBotRunning) "Step #${botState.currentStep}" else "बोट को गेम खेलने दें",
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Single Step Button
                    OutlinedButton(
                        onClick = { controller.executeSingleStep() },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.SkipNext, contentDescription = "Step", tint = CyberCyan, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Step", fontSize = 11.sp, color = Color.White)
                    }

                    Spacer(Modifier.width(8.dp))

                    // Play / Pause Toggle
                    Button(
                        onClick = {
                            if (botState.isBotRunning) {
                                controller.stopBot()
                            } else {
                                controller.startBot()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (botState.isBotRunning) Color(0xFFFF5252) else NeonGreen
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(
                            if (botState.isBotRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = if (botState.isBotRunning) Color.White else Color(0xFF00363D),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = if (botState.isBotRunning) "Stop" else "Auto",
                            color = if (botState.isBotRunning) Color.White else Color(0xFF00363D),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Embedded Game Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
        ) {
            when (selectedGame) {
                SimulatorGameType.RUNNER -> CyberRunnerGame(controller = controller)
                SimulatorGameType.TILE_MATCH -> TileGridMatchGame(controller = controller)
                SimulatorGameType.REACTION_BLITZ -> TapBlitzGame(controller = controller)
            }
        }
    }
}
