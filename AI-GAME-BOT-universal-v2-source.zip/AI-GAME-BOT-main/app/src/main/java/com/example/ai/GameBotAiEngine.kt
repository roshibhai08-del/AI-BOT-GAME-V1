package com.example.ai

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.model.ActionType
import com.example.model.ApiProvider
import com.example.model.BotAction
import com.example.model.BotConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class GameBotAiEngine(private val configProvider: () -> BotConfig) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val TAG = "GameBotAiEngine"
        private const val SYSTEM_PROMPT = """You are a UNIVERSAL 2D ANDROID GAME-PLAYING AI AGENT.
You must inspect the provided mobile game screenshot and dynamically understand what is happening on screen.
DO NOT assume a predefined game. DO NOT default to Obstacle Runner or reuse prior game assumptions.

Analyze:
1. Game Title & Category (Math/Quiz, Puzzle, Match-3, Ludo, Chess, Checkers, Card Game, Memory, Word, Trivia, Runner, Platformer, Arcade, Strategy, Board, Tile 2048, Racing, Rhythm, Physics, Drag-and-Drop, Educational, Reaction, Logic, Number, Maze, 2D Shooter, Simulation, or Unknown).
2. Level, Current State (playing, victory screen, game-over screen, dialog menu, or discovery).
3. Primary Objective (what is the game asking the player to do right now?).
4. Controllable Player entity, targets, obstacles, answers, tiles, or cards.
5. Optimal Next Action (tap, double_tap, long_press, swipe_up, swipe_down, swipe_left, swipe_right, drag, wait, back, retry, done).
For tap: specify center coordinates (x, y) of the target.
For drag/swipe: specify start (x, y) and destination (x2, y2).
6. Confidence (0 to 100). If uncertain or low confidence, choose action "wait".
7. Expected Result (what visual change should occur after this action).

Reply with ONLY valid JSON:
{
  "game": "Exact detected game name or genre",
  "genre": "category_name",
  "level": "current level or stage",
  "state": "playing|victory|game_over|menu|discovery",
  "objective": "current goal to achieve",
  "thought": "Reasoning explaining why this specific action was chosen",
  "action": "tap"|"double_tap"|"long_press"|"swipe_up"|"swipe_down"|"swipe_left"|"swipe_right"|"drag"|"wait"|"back"|"retry"|"done",
  "x": int, "y": int, "x2": int, "y2": int,
  "duration_ms": int,
  "confidence": float,
  "expected_result": "expected screen change"
}"""
    }

    suspend fun analyzeScreenshot(
        bitmap: Bitmap,
        history: List<String>,
        stepNumber: Int
    ): Pair<BotAction, Float> = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val config = configProvider()

        val realW = bitmap.width
        val realH = bitmap.height
        val scale = realW.toFloat() / config.imgWidth.toFloat()
        val targetH = (realH / scale).toInt().coerceAtLeast(1)

        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, config.imgWidth, targetH, true)
        val stream = ByteArrayOutputStream()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        val imageBytes = stream.toByteArray()
        val base64Image = Base64.encodeToString(imageBytes, Base64.NO_WRAP)

        var action: BotAction? = null

        when (config.apiProvider) {
            ApiProvider.GEMINI -> {
                val apiKey = if (config.customApiKey.isNotBlank()) {
                    config.customApiKey.trim()
                } else {
                    BuildConfig.GEMINI_API_KEY
                }

                if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
                    try {
                        action = callGeminiVision(base64Image, history, apiKey, config.geminiModel, stepNumber)
                    } catch (e: Exception) {
                        Log.e(TAG, "Gemini call failed, falling back to local vision engine: ${e.message}")
                    }
                }
            }
            ApiProvider.ANTHROPIC -> {
                if (config.customApiKey.isNotBlank()) {
                    try {
                        action = callAnthropicClaude(base64Image, history, config.customApiKey.trim(), stepNumber)
                    } catch (e: Exception) {
                        Log.e(TAG, "Anthropic call failed: ${e.message}")
                    }
                }
            }
            ApiProvider.SMART_SIMULATOR -> {
                // Evaluated below
            }
        }

        // If API call was skipped or failed or provider is SMART_SIMULATOR, use smart heuristic vision analyzer
        if (action == null) {
            action = fallbackVisionAnalysis(bitmap, history, stepNumber)
        }

        val elapsed = System.currentTimeMillis() - startTime
        val finalAction = action.copy(
            responseTimeMs = elapsed,
            stepNumber = stepNumber
        )

        // Safety purchase protection filter
        val safeAction = applySafetyCheck(finalAction, config)

        Pair(safeAction, scale)
    }

    private fun callGeminiVision(
        base64Image: String,
        history: List<String>,
        apiKey: String,
        modelName: String,
        stepNumber: Int
    ): BotAction {
        val config = configProvider()
        val model = if (modelName.isNotBlank() && modelName != "gemini-2.5-flash") modelName else "gemini-3.8-flash"
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        val targetDirective = if (config.targetGame != "Auto Detect" && config.targetGame.isNotBlank()) {
            "TARGET GAME SELECTED BY USER: ${config.targetGame}\nUSER GOAL / STRATEGY: ${config.customGoal}\n"
        } else if (config.customGoal.isNotBlank()) {
            "USER GOAL / STRATEGY: ${config.customGoal}\n"
        } else {
            ""
        }

        val historyText = if (history.isNotEmpty()) {
            "Recent actions: " + history.takeLast(5).joinToString(" | ") + "\nWhat is the next action?"
        } else {
            "First turn. Identify the game state and decide the single best next action to win/progress."
        }

        val fullPrompt = "$SYSTEM_PROMPT\n\n${targetDirective}$historyText"

        val rootJson = JSONObject().apply {
            val contentsArray = JSONArray()
            val contentObj = JSONObject().apply {
                val partsArray = JSONArray()
                // Text part
                partsArray.put(JSONObject().apply {
                    put("text", fullPrompt)
                })
                // Image part
                partsArray.put(JSONObject().apply {
                    put("inlineData", JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", base64Image)
                    })
                })
                put("parts", partsArray)
            }
            contentsArray.put(contentObj)
            put("contents", contentsArray)

            put("generationConfig", JSONObject().apply {
                put("temperature", 0.2)
                put("responseMimeType", "application/json")
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(rootJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string().orEmpty()

        if (!response.isSuccessful) {
            throw IllegalStateException("Gemini API HTTP ${response.code}: $responseBody")
        }

        val responseJson = JSONObject(responseBody)
        val text = responseJson.optJSONArray("candidates")
            ?.optJSONObject(0)
            ?.optJSONObject("content")
            ?.optJSONArray("parts")
            ?.optJSONObject(0)
            ?.optString("text").orEmpty()

        return parseAiJson(text, stepNumber)
    }

    private fun callAnthropicClaude(
        base64Image: String,
        history: List<String>,
        apiKey: String,
        stepNumber: Int
    ): BotAction {
        val url = "https://api.anthropic.com/v1/messages"
        val historyText = if (history.isNotEmpty()) {
            "Recent actions: " + history.takeLast(5).joinToString(" | ") + "\nWhat is the next action?"
        } else {
            "Identify the game and output next action JSON."
        }

        val rootJson = JSONObject().apply {
            put("model", "claude-3-5-sonnet-20241022")
            put("max_tokens", 400)
            put("system", SYSTEM_PROMPT)

            val messagesArray = JSONArray()
            val msgObj = JSONObject().apply {
                put("role", "user")
                val contentArray = JSONArray()
                contentArray.put(JSONObject().apply {
                    put("type", "image")
                    put("source", JSONObject().apply {
                        put("type", "base64")
                        put("media_type", "image/jpeg")
                        put("data", base64Image)
                    })
                })
                contentArray.put(JSONObject().apply {
                    put("type", "text")
                    put("text", historyText)
                })
                put("content", contentArray)
            }
            messagesArray.put(msgObj)
            put("messages", messagesArray)
        }

        val request = Request.Builder()
            .url(url)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .post(rootJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string().orEmpty()

        if (!response.isSuccessful) {
            throw IllegalStateException("Anthropic API HTTP ${response.code}: $responseBody")
        }

        val responseJson = JSONObject(responseBody)
        val contentArray = responseJson.optJSONArray("content")
        val text = contentArray?.optJSONObject(0)?.optString("text").orEmpty()

        return parseAiJson(text, stepNumber)
    }

    private fun parseAiJson(text: String, stepNumber: Int): BotAction {
        val pattern = Pattern.compile("\\{.*\\}", Pattern.DOTALL)
        val matcher = pattern.matcher(text)
        if (!matcher.find()) {
            throw IllegalArgumentException("Could not extract JSON from AI response: $text")
        }
        val jsonStr = matcher.group(0) ?: text
        val json = JSONObject(jsonStr)

        val game = json.optString("game", "Detected Mobile Game")
        val genre = json.optString("genre", "arcade")
        val thought = json.optString("thought", "Analyzing tactical layout and executing optimal move")
        val actionStr = json.optString("action", "wait").lowercase()
        val x = json.optInt("x", 360)
        val y = json.optInt("y", 640)
        val x2 = json.optInt("x2", x)
        val y2 = json.optInt("y2", y)
        val durationMs = json.optInt("duration_ms", 300)
        val confidence = json.optDouble("confidence", 88.0).toFloat()
        val expectedResult = json.optString("expected_result", "Screen state change")

        val actionType = when (actionStr) {
            "tap" -> ActionType.TAP
            "double_tap" -> ActionType.DOUBLE_TAP
            "long_press" -> ActionType.LONG_PRESS
            "swipe" -> ActionType.SWIPE
            "swipe_up" -> ActionType.SWIPE_UP
            "swipe_down" -> ActionType.SWIPE_DOWN
            "swipe_left" -> ActionType.SWIPE_LEFT
            "swipe_right" -> ActionType.SWIPE_RIGHT
            "drag" -> ActionType.DRAG
            "wait" -> ActionType.WAIT
            "back" -> ActionType.BACK
            "retry" -> ActionType.RETRY
            "done" -> ActionType.DONE
            else -> ActionType.WAIT
        }

        return BotAction(
            game = game,
            genre = genre,
            thought = thought,
            action = actionType,
            x = x,
            y = y,
            x2 = x2,
            y2 = y2,
            durationMs = durationMs,
            stepNumber = stepNumber,
            confidence = confidence,
            expectedResult = expectedResult
        )
    }

    private fun fallbackVisionAnalysis(bitmap: Bitmap, history: List<String>, stepNumber: Int): BotAction {
        val w = bitmap.width
        val h = bitmap.height

        val gameClassifier = com.example.engine.GameClassifier()
        val objectDetector = com.example.engine.ObjectDetector()
        val ocrManager = com.example.engine.OCRManager()

        // 1. Analyze text heuristically
        val textElements = ocrManager.detectTextRegionsHeuristic(bitmap)
        val textStrings = textElements.map { it.text }

        // 2. Classify dynamically
        val config = configProvider()
        val classification = gameClassifier.classify(bitmap, textStrings, config.targetGame)

        // 3. Detect visual entities
        val objects = objectDetector.detectObjects(bitmap)

        // 4. Determine optimal action
        val primaryTarget = objects.firstOrNull { it.type == com.example.model.ObjectType.TARGET }
            ?: objects.firstOrNull { it.type == com.example.model.ObjectType.BUTTON }
            ?: objects.firstOrNull()

        val targetX = if (primaryTarget != null) (primaryTarget.bounds.centerX() * w).toInt() else w / 2
        val targetY = if (primaryTarget != null) (primaryTarget.bounds.centerY() * h).toInt() else (h * 0.75f).toInt()

        val actionType = when (classification.category) {
            com.example.model.GameCategory.MATCH_3 -> ActionType.SWIPE_RIGHT
            com.example.model.GameCategory.TILE_GAME -> ActionType.SWIPE_UP
            com.example.model.GameCategory.RUNNER -> ActionType.SWIPE_UP
            com.example.model.GameCategory.DRAG_AND_DROP -> ActionType.DRAG
            else -> ActionType.TAP
        }

        val thought = if (classification.isUnknownFallback) {
            "अज्ञात 2D गेम - जनरल विज़ुअल मोड में लक्ष्य (${targetX}, ${targetY}) पर सुरक्षित इंटरैक्शन"
        } else {
            "${classification.category.displayName} पहचाना गया - ${actionType.label} क्रिया निष्पादित की जा रही है"
        }

        return BotAction(
            game = classification.detectedGameTitle,
            genre = classification.category.displayName,
            thought = thought,
            action = actionType,
            x = targetX,
            y = targetY,
            x2 = (targetX + 300).coerceAtMost(w - 50),
            y2 = targetY,
            durationMs = 280,
            stepNumber = stepNumber,
            confidence = if (classification.isUnknownFallback) 60f else 88f,
            expectedResult = "Game state visual change"
        )
    }

    private fun applySafetyCheck(action: BotAction, config: BotConfig): BotAction {
        if (!config.safetyPurchaseProtection) return action

        val textToCheck = "${action.thought} ${action.game}".lowercase()
        val dangerKeywords = listOf(
            "buy", "purchase", "real money", "store", "rupees", "inr", "$", "₹",
            "credit card", "paytm", "upi", "google play balance", "gems pack purchase"
        )

        val isDangerous = dangerKeywords.any { textToCheck.contains(it) }
        return if (isDangerous) {
            action.copy(
                action = ActionType.WAIT,
                thought = "🛡️ सुरक्षा गार्ड: असली पैसे की खरीद को रोका गया (Safety Blocked)",
                isSafetyBlocked = true
            )
        } else {
            action
        }
    }
}
