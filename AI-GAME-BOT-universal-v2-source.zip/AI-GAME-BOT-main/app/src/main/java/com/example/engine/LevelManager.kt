package com.example.engine

import android.graphics.RectF
import com.example.model.DetectedObject
import com.example.model.ObjectType

class LevelManager {

    var currentLevel: String = "Level 1"
        private set

    fun detectLevel(texts: List<String>): String {
        for (t in texts) {
            val lower = t.lowercase()
            if (lower.contains("level") || lower.contains("stage") || lower.contains("wave") || lower.contains("round")) {
                val match = Regex("""(?:level|stage|wave|round)\s*(\d+)""", RegexOption.IGNORE_CASE).find(t)
                if (match != null) {
                    currentLevel = "Level ${match.groupValues[1]}"
                    return currentLevel
                }
                currentLevel = t.trim()
                return currentLevel
            }
        }
        return currentLevel
    }

    fun reset() {
        currentLevel = "Level 1"
    }
}
