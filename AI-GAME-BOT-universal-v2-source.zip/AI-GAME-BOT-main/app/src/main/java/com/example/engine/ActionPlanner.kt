package com.example.engine

import android.graphics.Bitmap
import com.example.model.ActionType
import com.example.model.CalibrationProfile
import com.example.model.DebugOverlayState
import com.example.model.DetectedObject
import com.example.model.GameCategory
import com.example.model.GameStateStatus
import com.example.model.IdentitySource
import com.example.model.PlannedAction

data class AnalysisPlan(
    val gameTitle: String,
    val category: GameCategory,
    val identitySource: IdentitySource,
    val level: String,
    val stateStatus: GameStateStatus,
    val objective: String,
    val questionText: String = "",
    val optionsText: List<String> = emptyList(),
    val calculatedAnswer: String = "",
    val selectedAnswer: String = "",
    val detectedObjects: List<DetectedObject>,
    val plannedAction: PlannedAction,
    val debugOverlayState: DebugOverlayState
)

class ActionPlanner(
    private val coordinateMapper: CoordinateMapper,
    private val gameIdentityDetector: GameIdentityDetector,
    private val gameClassifier: GameClassifier,
    private val objectDetector: ObjectDetector,
    private val ocrManager: OCRManager,
    private val mathEngine: MathEngine,
    private val levelManager: LevelManager,
    private val strategyEngine: StrategyEngine
) {

    /**
     * Executes the full pipeline:
     * Screen Frame -> Game Identity Detection -> Math Engine / Classification -> State Synthesis -> Action Planning.
     */
    fun analyzeAndPlan(
        bitmap: Bitmap,
        explicitTarget: String,
        calibration: CalibrationProfile,
        minConfidenceThreshold: Float,
        stepNumber: Int,
        simulatedPackage: String? = null
    ): AnalysisPlan {
        // 1. Detect OCR and contrast texts
        val textElements = ocrManager.detectTextRegionsHeuristic(bitmap)
        val textStrings = textElements.map { it.text }

        // 2. DETECT THE ACTUAL GAME NAME via prioritized 5-tier pipeline
        val identity = gameIdentityDetector.detectIdentity(bitmap, textStrings, simulatedPackage)

        // 3. PRIORITY CHECK: Dedicated Math Engine
        val mathResult = mathEngine.analyzeMathScreen(textStrings, calibration, stepNumber)

        val gameTitle: String
        val category: GameCategory
        val objects: List<DetectedObject>
        val action: PlannedAction
        val qText: String
        val optText: List<String>
        val calcAns: String
        val selAns: String
        val stateStatus: GameStateStatus

        if (mathResult.isMathScreen) {
            // Match screen verified!
            gameTitle = if (identity.gameName != "Unidentified Game") identity.gameName else "MathGro"
            category = GameCategory.MATH_QUIZ
            stateStatus = GameStateStatus.PLAYING
            qText = mathResult.questionText
            optText = mathResult.detectedOptions
            calcAns = mathResult.calculatedAnswerStr
            selAns = mathResult.matchingOption ?: mathResult.calculatedAnswerStr

            // Create WHITE question box, PURPLE option boxes, and GREEN target box
            objects = objectDetector.createMathBoundingBoxes(
                questionText = mathResult.questionText,
                options = mathResult.detectedOptions,
                targetOption = mathResult.matchingOption,
                questionBounds = mathResult.questionBounds,
                targetBounds = mathResult.targetOptionBounds
            )

            // High-confidence TAP on exact center of the correct answer button
            action = mathEngine.createMathTapAction(mathResult, calibration, stepNumber)
        } else {
            // Standard Universal 2D Game Path
            val classification = gameClassifier.classify(bitmap, textStrings, explicitTarget)
            category = classification.category
            gameTitle = if (identity.gameName != "Unidentified Game") identity.gameName else classification.detectedGameTitle
            stateStatus = if (classification.isUnknownFallback) GameStateStatus.DISCOVERY else GameStateStatus.PLAYING
            qText = ""
            optText = emptyList()
            calcAns = ""
            selAns = ""

            // Detect visual entities
            objects = objectDetector.detectObjects(bitmap)

            // Plan action through strategy engine
            action = strategyEngine.planNextAction(
                category = category,
                stateStatus = stateStatus,
                objects = objects,
                detectedTexts = textStrings,
                calibration = calibration,
                minConfidenceThreshold = minConfidenceThreshold,
                stepNumber = stepNumber
            )
        }

        // 4. Detect level
        val level = levelManager.detectLevel(textStrings)

        // 5. Assemble Debug Overlay State
        val crosshairX = action.startX.toFloat()
        val crosshairY = action.startY.toFloat()

        val debugOverlayState = DebugOverlayState(
            isDebugEnabled = true,
            detectedGame = gameTitle,
            gameCategory = category,
            identitySource = identity.source,
            currentLevel = level,
            currentState = stateStatus,
            objective = action.objective,
            questionText = qText,
            optionsText = optText,
            calculatedAnswer = calcAns,
            selectedAnswer = selAns,
            detectedObjects = objects,
            plannedAction = action,
            confidenceScore = action.confidence,
            crosshairX = crosshairX,
            crosshairY = crosshairY,
            lastVerificationResult = if (action.confidence < minConfidenceThreshold) {
                "LOW CONFIDENCE — WAITING / REANALYZING"
            } else {
                "Action planned: ${action.actionType.label} @ (${action.startX}, ${action.startY})"
            }
        )

        return AnalysisPlan(
            gameTitle = gameTitle,
            category = category,
            identitySource = identity.source,
            level = level,
            stateStatus = stateStatus,
            objective = action.objective,
            questionText = qText,
            optionsText = optText,
            calculatedAnswer = calcAns,
            selectedAnswer = selAns,
            detectedObjects = objects,
            plannedAction = action,
            debugOverlayState = debugOverlayState
        )
    }
}
