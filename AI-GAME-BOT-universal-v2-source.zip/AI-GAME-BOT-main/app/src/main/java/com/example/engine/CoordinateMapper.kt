package com.example.engine

import android.content.Context
import android.graphics.PointF
import android.graphics.RectF
import android.util.DisplayMetrics
import android.view.WindowManager
import com.example.model.CalibrationProfile

/**
 * CoordinateMapper:
 * Accurately transforms coordinates between Screenshot resolution,
 * normalized [0..1] space, and physical Android display coordinates.
 *
 * Accounts for:
 * - Screenshot width/height vs Physical Display width/height
 * - Device density and aspect ratio
 * - Window insets, status bar & navigation bar offsets
 * - User calibration profile (offsets & scale adjustments)
 */
class CoordinateMapper(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    var physicalWidth: Int = 1080
        private set
    var physicalHeight: Int = 2400
        private set
    var densityDpi: Int = DisplayMetrics.DENSITY_DEFAULT
        private set

    init {
        updateDisplayMetrics()
    }

    fun updateDisplayMetrics() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        physicalWidth = metrics.widthPixels.coerceAtLeast(1)
        physicalHeight = metrics.heightPixels.coerceAtLeast(1)
        densityDpi = metrics.densityDpi
    }

    /**
     * Converts a normalized coordinate (0.0 .. 1.0) into physical screen pixel coordinate.
     */
    fun normalizedToPhysical(
        normalizedX: Float,
        normalizedY: Float,
        calibration: CalibrationProfile = CalibrationProfile()
    ): PointF {
        val basePhysicalX = normalizedX * physicalWidth
        val basePhysicalY = normalizedY * physicalHeight

        // Apply calibration scale and offsets
        val calibratedX = (basePhysicalX * calibration.scaleX) + calibration.offsetX
        val calibratedY = (basePhysicalY * calibration.scaleY) + calibration.offsetY

        // Clamp safely to physical screen boundaries
        val finalX = calibratedX.coerceIn(0f, physicalWidth.toFloat())
        val finalY = calibratedY.coerceIn(0f, physicalHeight.toFloat())

        return PointF(finalX, finalY)
    }

    /**
     * Converts screenshot pixel coordinates into physical display pixel coordinates.
     */
    fun screenshotToPhysical(
        screenshotX: Float,
        screenshotY: Float,
        screenshotWidth: Int,
        screenshotHeight: Int,
        calibration: CalibrationProfile = CalibrationProfile()
    ): PointF {
        if (screenshotWidth <= 0 || screenshotHeight <= 0) {
            return PointF(screenshotX, screenshotY)
        }
        val normX = screenshotX / screenshotWidth.toFloat()
        val normY = screenshotY / screenshotHeight.toFloat()
        return normalizedToPhysical(normX, normY, calibration)
    }

    /**
     * Converts a normalized RectF [0..1] to physical RectF in screen pixels.
     */
    fun normalizedRectToPhysical(
        normRect: RectF,
        calibration: CalibrationProfile = CalibrationProfile()
    ): RectF {
        val topLeft = normalizedToPhysical(normRect.left, normRect.top, calibration)
        val bottomRight = normalizedToPhysical(normRect.right, normRect.bottom, calibration)
        return RectF(topLeft.x, topLeft.y, bottomRight.x, bottomRight.y)
    }

    /**
     * Returns the exact center point of a normalized bounding box in physical display coordinates.
     */
    fun getCenterPhysical(
        normRect: RectF,
        calibration: CalibrationProfile = CalibrationProfile()
    ): PointF {
        val centerX = normRect.centerX()
        val centerY = normRect.centerY()
        return normalizedToPhysical(centerX, centerY, calibration)
    }
}
