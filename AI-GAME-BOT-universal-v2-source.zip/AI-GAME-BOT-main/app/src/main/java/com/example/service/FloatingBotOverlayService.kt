package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.controller.GameBotController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FloatingBotOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var isExpanded = false

    companion object {
        const val CHANNEL_ID = "game_bot_overlay_channel"
        const val NOTIFICATION_ID = 2001
        var isOverlayRunning = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, FloatingBotOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingBotOverlayService::class.java)
            context.stopService(intent)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isOverlayRunning = true
        createNotificationChannel()
        val notification = buildForegroundNotification()
        startForeground(NOTIFICATION_ID, notification)
        initOverlayUi()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Game Bot Floating Controls",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live status and controls for AI Game Bot"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AI Game Bot Active")
            .setContentText("Overlay active - Ready to detect and play games")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initOverlayUi() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 200
        }

        val rootLayout = FrameLayout(this)

        // Collapsed bubble
        val collapsedBadge = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 16, 24, 16)
            background = GradientDrawable().apply {
                setColor(0xEE0B0F19.toInt())
                setStroke(3, 0xFF00E5FF.toInt())
                cornerRadius = 60f
            }
            elevation = 16f
        }

        val dotView = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(24, 24).apply {
                marginEnd = 16
            }
            background = GradientDrawable().apply {
                setColor(0xFF00E676.toInt())
                shape = GradientDrawable.OVAL
            }
        }

        val labelView = TextView(this).apply {
            text = "AI BOT"
            setTextColor(0xFF00E5FF.toInt())
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        collapsedBadge.addView(dotView)
        collapsedBadge.addView(labelView)

        // Expanded control panel
        val expandedPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 28, 32, 28)
            background = GradientDrawable().apply {
                setColor(0xF50F1422.toInt())
                setStroke(2, 0xFF7C4DFF.toInt())
                cornerRadius = 32f
            }
            visibility = View.GONE
            elevation = 20f
        }

        val gameTitle = TextView(this).apply {
            text = "🎮 Game Bot HUD"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        val thoughtText = TextView(this).apply {
            text = "Status: Bot Ready. Open game & tap Start"
            setTextColor(0xFF94A3B8.toInt())
            textSize = 12f
            setPadding(0, 10, 0, 16)
        }

        val buttonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val actionBtn = Button(this).apply {
            text = "▶ START"
            setTextColor(0xFF00363D.toInt())
            textSize = 12f
            background = GradientDrawable().apply {
                setColor(0xFF00E5FF.toInt())
                cornerRadius = 20f
            }
            setPadding(24, 8, 24, 8)
        }

        val stepBtn = Button(this).apply {
            text = "⏭ STEP"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 12f
            background = GradientDrawable().apply {
                setColor(0xFF263238.toInt())
                cornerRadius = 20f
            }
            setPadding(24, 8, 24, 8)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = 12
            }
        }

        val closeBtn = Button(this).apply {
            text = "✖"
            setTextColor(0xFFFF5252.toInt())
            textSize = 12f
            background = GradientDrawable().apply {
                setColor(0xFF1E293B.toInt())
                cornerRadius = 20f
            }
            setPadding(16, 8, 16, 8)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = 12
            }
        }

        buttonsRow.addView(actionBtn)
        buttonsRow.addView(stepBtn)
        buttonsRow.addView(closeBtn)

        expandedPanel.addView(gameTitle)
        expandedPanel.addView(thoughtText)
        expandedPanel.addView(buttonsRow)

        rootLayout.addView(collapsedBadge)
        rootLayout.addView(expandedPanel)

        // Dragging & Click Handling
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = false

        rootLayout.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                        isClick = false
                    }
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager?.updateViewLayout(rootLayout, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        isExpanded = !isExpanded
                        if (isExpanded) {
                            collapsedBadge.visibility = View.GONE
                            expandedPanel.visibility = View.VISIBLE
                        } else {
                            collapsedBadge.visibility = View.VISIBLE
                            expandedPanel.visibility = View.GONE
                        }
                    }
                    true
                }
                else -> false
            }
        }

        // Button Click Listeners
        actionBtn.setOnClickListener {
            val controller = GameBotController.instance
            if (controller != null) {
                if (controller.botState.value.isBotRunning) {
                    controller.stopBot()
                    actionBtn.text = "▶ START"
                } else {
                    controller.startBot()
                    actionBtn.text = "⏸ PAUSE"
                }
            }
        }

        stepBtn.setOnClickListener {
            val controller = GameBotController.instance
            if (controller != null) {
                if (controller.botState.value.pendingStepAction != null) {
                    controller.executePlannedStep()
                } else {
                    controller.planSingleStepOnly()
                }
            }
        }

        closeBtn.setOnClickListener {
            stopSelf()
        }

        // Collect state updates from Controller
        serviceScope.launch {
            GameBotController.instance?.botState?.collectLatest { state ->
                actionBtn.text = if (state.isBotRunning) "⏸ STOP" else "▶ START"
                val runningColor = when {
                    state.isBotRunning -> 0xFF00E676.toInt()
                    state.pendingStepAction != null -> 0xFF00E5FF.toInt()
                    else -> 0xFFFFB300.toInt()
                }
                (dotView.background as? GradientDrawable)?.setColor(runningColor)

                stepBtn.text = if (state.pendingStepAction != null) "⚡ EXECUTE" else "⏭ 1 STEP"

                gameTitle.text = "🎮 ${state.currentGameName} (${state.gameCategory.displayName})"
                val lastThought = state.lastAction?.thought ?: state.statusMessage
                val obj = if (state.currentObjective.isNotBlank()) "${state.currentObjective} • " else ""
                thoughtText.text = "$obj[Step ${state.currentStep} | ${state.confidenceScore.toInt()}% Conf]\n$lastThought"
            }
        }

        overlayView = rootLayout
        windowManager?.addView(rootLayout, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        isOverlayRunning = false
        if (overlayView != null) {
            windowManager?.removeView(overlayView)
            overlayView = null
        }
    }
}
