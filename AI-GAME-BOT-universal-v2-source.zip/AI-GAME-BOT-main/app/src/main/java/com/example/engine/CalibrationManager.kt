package com.example.engine

import android.content.Context
import android.content.SharedPreferences
import com.example.model.CalibrationProfile

class CalibrationManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ai_gamebot_calibration", Context.MODE_PRIVATE)

    var currentProfile: CalibrationProfile = loadProfile()
        private set

    fun loadProfile(): CalibrationProfile {
        val w = prefs.getInt("display_width", 1080)
        val h = prefs.getInt("display_height", 2400)
        val offX = prefs.getFloat("offset_x", 0f)
        val offY = prefs.getFloat("offset_y", 0f)
        val scX = prefs.getFloat("scale_x", 1.0f)
        val scY = prefs.getFloat("scale_y", 1.0f)
        val time = prefs.getLong("calibrated_time", 0L)

        return CalibrationProfile(w, h, offX, offY, scX, scY, time)
    }

    fun updateCalibration(offsetX: Float, offsetY: Float, scaleX: Float, scaleY: Float) {
        currentProfile = currentProfile.copy(
            offsetX = offsetX,
            offsetY = offsetY,
            scaleX = scaleX,
            scaleY = scaleY,
            lastCalibratedTime = System.currentTimeMillis()
        )
        saveProfile(currentProfile)
    }

    fun resetCalibration(displayWidth: Int, displayHeight: Int) {
        currentProfile = CalibrationProfile(
            displayWidth = displayWidth,
            displayHeight = displayHeight,
            offsetX = 0f,
            offsetY = 0f,
            scaleX = 1.0f,
            scaleY = 1.0f,
            lastCalibratedTime = System.currentTimeMillis()
        )
        saveProfile(currentProfile)
    }

    private fun saveProfile(profile: CalibrationProfile) {
        prefs.edit()
            .putInt("display_width", profile.displayWidth)
            .putInt("display_height", profile.displayHeight)
            .putFloat("offset_x", profile.offsetX)
            .putFloat("offset_y", profile.offsetY)
            .putFloat("scale_x", profile.scaleX)
            .putFloat("scale_y", profile.scaleY)
            .putLong("calibrated_time", profile.lastCalibratedTime)
            .apply()
    }
}
