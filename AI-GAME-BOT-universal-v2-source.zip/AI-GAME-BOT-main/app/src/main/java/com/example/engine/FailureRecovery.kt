package com.example.engine

import android.graphics.RectF
import com.example.model.DetectedObject
import com.example.model.ObjectType

data class FailureInfo(
    val isGameOver: Boolean,
    val failureReason: String = "",
    val retryButtonBounds: RectF? = null
)

class FailureRecovery {

    private val failureKeywords = listOf(
        "game over", "try again", "failed", "out of moves",
        "defeat", "busted", "crashed", "wasted", "restart"
    )

    private val retryKeywords = listOf(
        "retry", "restart", "play again", "try again", "replay", "revive"
    )

    private var failureCount = 0

    fun checkFailure(detectedTexts: List<String>, objects: List<DetectedObject>): FailureInfo {
        val allText = detectedTexts.joinToString(" ").lowercase()
        val isFail = failureKeywords.any { allText.contains(it) }

        if (!isFail) {
            return FailureInfo(isGameOver = false)
        }

        failureCount++

        // Look for retry button in detected objects
        var retryBounds: RectF? = null
        for (obj in objects) {
            val labelLower = obj.label.lowercase()
            if (retryKeywords.any { labelLower.contains(it) }) {
                retryBounds = obj.bounds
                break
            }
        }

        // Standard center restart button fallback if bounds not distinct
        if (retryBounds == null) {
            retryBounds = RectF(0.30f, 0.65f, 0.70f, 0.78f)
        }

        return FailureInfo(
            isGameOver = true,
            failureReason = "Game Over state encountered ($failureCount times)",
            retryButtonBounds = retryBounds
        )
    }

    fun getFailureCount(): Int = failureCount

    fun reset() {
        failureCount = 0
    }
}
