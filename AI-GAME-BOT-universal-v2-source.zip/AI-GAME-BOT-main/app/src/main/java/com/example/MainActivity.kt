package com.example

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.controller.GameBotController
import com.example.service.GameBotAccessibilityService
import com.example.service.ScreenCaptureService
import com.example.ui.screens.ArcadeScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ScriptCompareScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MyApplicationTheme
import java.io.ByteArrayOutputStream

enum class MainNavTab(val title: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Home),
    ARCADE("Game Arcade", Icons.Default.SportsEsports),
    SCRIPT_COMPARE("Python ADB", Icons.Default.Code),
    SETTINGS("Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "MainActivity"
        var instance: MainActivity? = null
            private set

        /**
         * Helper function to convert a Bitmap to Base64 format for the Gemini API.
         * Default compression: JPEG at 80% quality, NO_WRAP encoding.
         */
        fun convertBitmapToBase64(bitmap: Bitmap, quality: Int = 80): String {
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(10, 100), outputStream)
            val bytes = outputStream.toByteArray()
            return Base64.encodeToString(bytes, Base64.NO_WRAP)
        }
    }

    private lateinit var controller: GameBotController
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var latestCapturedBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        enableEdgeToEdge()
        controller = GameBotController.initialize(this)

        setContent {
            MyApplicationTheme {
                val serviceActive by GameBotAccessibilityService.isServiceActive.collectAsState()
                val isScreenCapturing by ScreenCaptureService.isCapturing.collectAsState()
                var currentTab by remember { mutableStateOf(MainNavTab.DASHBOARD) }

                val mediaProjectionManager = remember {
                    getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                }

                // MediaProjection Permission Launcher
                val screenCaptureLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    if (result.resultCode == RESULT_OK && result.data != null) {
                        val data = result.data!!
                        // Start foreground service which manages MediaProjection and VirtualDisplay safely
                        ScreenCaptureService.start(this, result.resultCode, data)
                        controller.updateScreenCaptureStatus(true)
                        Toast.makeText(this, "Screen Capture active for Gemini AI", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Screen capture permission was not granted", Toast.LENGTH_SHORT).show()
                    }
                }

                val onToggleScreenCapture: () -> Unit = {
                    if (isScreenCapturing) {
                        releaseVirtualDisplay()
                        controller.updateScreenCaptureStatus(false)
                        Toast.makeText(this, "Screen capture stopped", Toast.LENGTH_SHORT).show()
                    } else {
                        val captureIntent = mediaProjectionManager.createScreenCaptureIntent()
                        screenCaptureLauncher.launch(captureIntent)
                    }
                }

                LaunchedEffect(isScreenCapturing) {
                    controller.updateScreenCaptureStatus(isScreenCapturing)
                }

                BackHandler(enabled = currentTab != MainNavTab.DASHBOARD) {
                    currentTab = MainNavTab.DASHBOARD
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color(0xFF0B0F19),
                    bottomBar = {
                        NavigationBar(
                            containerColor = Color(0xFF131926),
                            tonalElevation = 8.dp
                        ) {
                            MainNavTab.values().forEach { tab ->
                                val selected = currentTab == tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            tab.icon,
                                            contentDescription = tab.title,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tab.title,
                                            fontSize = 11.sp,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFF00363D),
                                        selectedTextColor = CyberCyan,
                                        indicatorColor = CyberCyan,
                                        unselectedIconColor = Color(0xFF64748B),
                                        unselectedTextColor = Color(0xFF64748B)
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    when (currentTab) {
                        MainNavTab.DASHBOARD -> HomeScreen(
                            controller = controller,
                            onNavigateToArcade = { currentTab = MainNavTab.ARCADE },
                            onToggleScreenCapture = onToggleScreenCapture,
                            modifier = Modifier.padding(innerPadding)
                        )
                        MainNavTab.ARCADE -> ArcadeScreen(
                            controller = controller,
                            modifier = Modifier.padding(innerPadding)
                        )
                        MainNavTab.SCRIPT_COMPARE -> ScriptCompareScreen(
                            modifier = Modifier.padding(innerPadding)
                        )
                        MainNavTab.SETTINGS -> SettingsScreen(
                            controller = controller,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }

    /**
     * Delegates VirtualDisplay setup to ScreenCaptureService to comply with
     * Android 14+ FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION requirement.
     */
    fun setupVirtualDisplay(resultCode: Int, data: Intent) {
        ScreenCaptureService.start(this, resultCode, data)
    }

    /**
     * Releases VirtualDisplay, ImageReader, and MediaProjection resources.
     */
    fun releaseVirtualDisplay() {
        ScreenCaptureService.stop(this)
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
            mediaProjection?.stop()
            mediaProjection = null
            latestCapturedBitmap = null
            Log.d(TAG, "VirtualDisplay and MediaProjection released successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing VirtualDisplay: ${e.message}")
        }
    }

    /**
     * Retrieves the latest captured screen frame Bitmap from the VirtualDisplay stream.
     */
    fun captureCurrentBitmap(): Bitmap? {
        return ScreenCaptureService.instance?.captureLatestBitmap() ?: latestCapturedBitmap
    }

    /**
     * Helper to convert a given Bitmap to Base64 format for Gemini API.
     */
    fun getBase64ScreenForGemini(quality: Int = 80): String? {
        val bmp = captureCurrentBitmap() ?: return null
        return convertBitmapToBase64(bmp, quality)
    }

    override fun onResume() {
        super.onResume()
        checkSystemPermissions()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseVirtualDisplay()
        instance = null
    }

    private fun checkSystemPermissions() {
        val isA11y = isAccessibilityServiceEnabled(this, GameBotAccessibilityService::class.java) ||
                GameBotAccessibilityService.instance != null
        controller.updateAccessibilityStatus(isA11y)

        val isOverlay = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
        controller.updateOverlayStatus(isOverlay)

        val isCapturing = ScreenCaptureService.isCapturing.value || virtualDisplay != null
        controller.updateScreenCaptureStatus(isCapturing)
    }

    private fun isAccessibilityServiceEnabled(
        context: Context,
        serviceClass: Class<out AccessibilityService>
    ): Boolean {
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServices)
        val componentName = ComponentName(context, serviceClass)
        while (colonSplitter.hasNext()) {
            val componentNameString = colonSplitter.next()
            val enabledComponent = ComponentName.unflattenFromString(componentNameString)
            if (enabledComponent != null && enabledComponent == componentName) {
                return true
            }
        }
        return false
    }
}
