package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDark = Color(0xFF00B0FF)
val NeonGreen = Color(0xFF00E676)
val ElectricPurple = Color(0xFF7C4DFF)
val NeonAmber = Color(0xFFFFB300)
val DangerRed = Color(0xFFFF5252)

val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131926)
val DarkSurfaceVariant = Color(0xFF1B2335)
val DarkBorder = Color(0xFF28344D)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val BotActiveGlow = Color(0xFF00E5FF)
val BotSuccessGlow = Color(0xFF00E676)
val BotWarningGlow = Color(0xFFFFB300)
