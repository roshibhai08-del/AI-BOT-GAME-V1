package com.example.model

import android.graphics.Bitmap
import android.graphics.RectF

enum class ActionType(val label: String, val hindiLabel: String) {
    TAP("Tap", "टैप करें"),
    DOUBLE_TAP("Double Tap", "डबल टैप"),
    LONG_PRESS("Long Press", "दबाकर रखें"),
    SWIPE("Swipe", "स्वाइप करें"),
    SWIPE_UP("Swipe Up", "ऊपर स्वाइप"),
    SWIPE_DOWN("Swipe Down", "नीचे स्वाइप"),
    SWIPE_LEFT("Swipe Left", "बाएं स्वाइप"),
    SWIPE_RIGHT("Swipe Right", "दाएं स्वाइप"),
    DRAG("Drag", "खींचें (Drag)"),
    DROP("Drop", "छोड़ें (Drop)"),
    WAIT("Wait", "इंतज़ार"),
    BACK("Back", "वापस जाएं"),
    RETRY("Retry", "दोबारा खेलें"),
    PAUSE("Pause", "रोकें"),
    RESUME("Resume", "जारी रखें"),
    DONE("Done", "टास्क पूरा")
}

enum class GameCategory(val displayName: String, val hindiName: String) {
    MATH_QUIZ("Math / Quiz", "गणित / क्विज़"),
    PUZZLE("Puzzle", "पहेली (Puzzle)"),
    MATCH_3("Match-3", "मैच-3"),
    LUDO("Ludo", "लूडो"),
    CHESS("Chess", "शतरंज"),
    CHECKERS("Checkers", "चेकर्स"),
    CARD_GAME("Card Game", "ताश / कार्ड गेम"),
    MEMORY_GAME("Memory Game", "मेमोरी गेम"),
    WORD_GAME("Word Game", "शब्द खेल"),
    TRIVIA("Trivia", "सामान्य ज्ञान / ट्रिविया"),
    RUNNER("Runner", "रनर (Runner)"),
    PLATFORMER("Platformer", "प्लैटफ़ॉर्मर"),
    ARCADE("Arcade", "आर्केड"),
    STRATEGY("Strategy", "रणनीति (Strategy)"),
    BOARD_GAME("Board Game", "बोर्ड गेम"),
    TILE_GAME("Tile Game", "टाइल गेम (2048)"),
    RACING("Racing", "रेसिंग"),
    RHYTHM_TIMING("Rhythm / Timing", "रिदम / टाइमिंग"),
    PHYSICS_BASED("Physics-based", "फ़िज़िक्स आधारित"),
    DRAG_AND_DROP("Drag-and-Drop", "ड्रैग और ड्रॉप"),
    EDUCATIONAL("Educational", "शैक्षणिक"),
    REACTION("Reaction", "रिएक्शन स्पीड"),
    LOGIC("Logic", "लॉजिक"),
    NUMBER_GAME("Number Game", "संख्या खेल"),
    MAZE("Maze", "भूलभुलैया"),
    SHOOTER_2D("2D Shooter", "2D शूटर"),
    SIMULATION("Simulation", "सिम्युलेशन"),
    UNKNOWN("Unknown 2D Game", "अज्ञात 2D गेम")
}

enum class IdentitySource(val label: String) {
    APP_LABEL("App Label"),
    PACKAGE("Package"),
    OCR("OCR / Header"),
    VISUAL("Visual / Logo"),
    INFERENCE("Inference"),
    SIMULATOR("Arcade Simulator")
}

enum class ObjectType {
    PLAYER,
    TARGET,
    OBSTACLE,
    BUTTON,
    CARD,
    TILE,
    NUMBER,
    TEXT,
    TIMER,
    SCORE,
    HEALTH,
    DIALOG,
    VICTORY_BANNER,
    RETRY_BUTTON,
    INTERACTIVE,
    QUESTION,
    ANSWER_OPTION
}

data class DetectedObject(
    val id: String,
    val type: ObjectType,
    val label: String,
    val bounds: RectF, // Normalized [0..1]
    val confidence: Float, // 0..1
    val colorHex: Long = 0xFF00FF00
)

data class PlannedAction(
    val actionType: ActionType = ActionType.WAIT,
    val startX: Int = 0,
    val startY: Int = 0,
    val endX: Int = 0,
    val endY: Int = 0,
    val durationMs: Long = 300L,
    val confidence: Float = 0f, // 0..100%
    val thought: String = "",
    val objective: String = "Detecting screen...",
    val expectedResult: String = "",
    val actualResult: String = "",
    val stepNumber: Int = 0,
    val isVerified: Boolean = false
)

data class CalibrationProfile(
    val displayWidth: Int = 1080,
    val displayHeight: Int = 2400,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val scaleX: Float = 1.0f,
    val scaleY: Float = 1.0f,
    val lastCalibratedTime: Long = 0L
)

enum class GameStateStatus(val label: String) {
    DISCOVERY("Discovery Mode"),
    PLAYING("Playing"),
    LEVEL_COMPLETE("Level Complete"),
    GAME_OVER("Game Over / Retry"),
    MENU("Menu / Dialog"),
    PAUSED("Paused"),
    WAITING_CONFIDENCE("Low Confidence — Waiting")
}

data class DebugOverlayState(
    val isDebugEnabled: Boolean = false,
    val detectedGame: String = "Auto Detecting...",
    val gameCategory: GameCategory = GameCategory.UNKNOWN,
    val identitySource: IdentitySource = IdentitySource.INFERENCE,
    val currentLevel: String = "Level 1",
    val currentState: GameStateStatus = GameStateStatus.DISCOVERY,
    val objective: String = "Observing game elements",
    val questionText: String = "",
    val optionsText: List<String> = emptyList(),
    val calculatedAnswer: String = "",
    val selectedAnswer: String = "",
    val detectedObjects: List<DetectedObject> = emptyList(),
    val plannedAction: PlannedAction? = null,
    val confidenceScore: Float = 0f,
    val crosshairX: Float = -1f,
    val crosshairY: Float = -1f,
    val lastVerificationResult: String = "Pending verification"
)

enum class ApiProvider(val displayName: String) {
    GEMINI("Gemini Vision AI (Built-in)"),
    ANTHROPIC("Claude Sonnet (Custom Key)"),
    SMART_SIMULATOR("Smart Vision Engine (Offline/Local)")
}

data class BotAction(
    val game: String = "Unknown Game",
    val genre: String = "arcade",
    val thought: String = "",
    val action: ActionType = ActionType.WAIT,
    val x: Int = 0,
    val y: Int = 0,
    val x2: Int = 0,
    val y2: Int = 0,
    val durationMs: Int = 300,
    val timestamp: Long = System.currentTimeMillis(),
    val responseTimeMs: Long = 0,
    val stepNumber: Int = 0,
    val isSafetyBlocked: Boolean = false,
    val confidence: Float = 85f,
    val expectedResult: String = "",
    val actualResult: String = ""
) {
    fun toActionString(): String {
        return when (action) {
            ActionType.TAP -> "tap $x,$y"
            ActionType.DOUBLE_TAP -> "double_tap $x,$y"
            ActionType.LONG_PRESS -> "long_press $x,$y"
            ActionType.SWIPE, ActionType.SWIPE_UP, ActionType.SWIPE_DOWN,
            ActionType.SWIPE_LEFT, ActionType.SWIPE_RIGHT -> "swipe $x,$y -> $x2,$y2"
            ActionType.DRAG -> "drag $x,$y -> $x2,$y2"
            ActionType.DROP -> "drop $x,$y"
            ActionType.WAIT -> "wait"
            ActionType.BACK -> "back"
            ActionType.RETRY -> "retry"
            ActionType.PAUSE -> "pause"
            ActionType.RESUME -> "resume"
            ActionType.DONE -> "done"
        }
    }
}

data class BotConfig(
    val maxSteps: Int = 300,
    val delaySeconds: Float = 1.0f,
    val imgWidth: Int = 720,
    val apiProvider: ApiProvider = ApiProvider.GEMINI,
    val customApiKey: String = "",
    val geminiModel: String = "gemini-3.8-flash",
    val targetGame: String = "Auto Detect",
    val customGoal: String = "Universal Game AI Auto-Detect",
    val isAutoDetectEnabled: Boolean = true,
    val isDebugOverlayEnabled: Boolean = true,
    val minConfidenceThreshold: Float = 55.0f, // Below this: Low Confidence Waiting
    val safetyPurchaseProtection: Boolean = true,
    val visualTouchFeedback: Boolean = true,
    val autoPlayContinuous: Boolean = true,
    val vibrationFeedback: Boolean = true
)

data class BotState(
    val isAccessibilityEnabled: Boolean = false,
    val isOverlayPermissionGranted: Boolean = false,
    val isScreenCaptureActive: Boolean = false,
    val isBotRunning: Boolean = false,
    val isPaused: Boolean = false,
    val isStepMode: Boolean = false,
    val isDetectingGame: Boolean = false,
    val pendingStepAction: PlannedAction? = null,
    val currentStep: Int = 0,
    val lastAction: BotAction? = null,
    val recentActions: List<BotAction> = emptyList(),
    val currentGameName: String = "Auto Detecting Screen...",
    val currentGenre: String = "Auto Detect",
    val gameCategory: GameCategory = GameCategory.UNKNOWN,
    val identitySource: IdentitySource = IdentitySource.INFERENCE,
    val detectedPackage: String = "",
    val gameStateStatus: GameStateStatus = GameStateStatus.DISCOVERY,
    val currentObjective: String = "Observing screen...",
    val currentLevel: String = "Level 1",
    val currentQuestion: String = "",
    val currentOptions: List<String> = emptyList(),
    val calculatedAnswer: String = "",
    val targetAnswer: String = "",
    val confidenceScore: Float = 0f,
    val statusMessage: String = "Bot Idle - Ready to play",
    val debugOverlayState: DebugOverlayState = DebugOverlayState(),
    val calibrationProfile: CalibrationProfile = CalibrationProfile(),
    val totalGesturesDispatched: Int = 0,
    val sessionStartTime: Long = 0L,
    val activeSimulatorGame: SimulatorGameType = SimulatorGameType.MATH_GRO
)

enum class SimulatorGameType(val title: String, val genre: String, val icon: String) {
    MATH_GRO("MathGro", "math", "🧮"),
    RUNNER("Cyber Runner", "runner", "🏃"),
    TILE_MATCH("Color Tile Grid", "puzzle", "🧩"),
    REACTION_BLITZ("Tap Blitz", "reaction", "🎯")
}

